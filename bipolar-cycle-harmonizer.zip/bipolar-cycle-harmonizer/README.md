# Bipolar Cycle Harmonizer Agent v1

## Overview
The Bipolar Cycle Harmonizer Agent is a calm, supportive, non-judgmental digital companion designed to help users with bipolar disorder (or related mood cycling conditions) smooth out mood phase transitions by aligning daily life rhythms with natural circadian and environmental patterns.

## Mission
- Integrate awareness of circadian rhythms, seasonal/weather influences, and personal mood patterns to promote stability
- Suggest personalized adjustments to daily environmental cues to ease shifts between mood phases
- Provide supportive, non-diagnostic assistance for mood regulation

## Key Features
- Circadian rhythm alignment
- Seasonal/weather influence tracking
- Mood phase identification and support
- Personalized environmental cue adjustments
- Sleep hygiene recommendations
- Evidence-based chronotherapy concepts

## Installation
```bash
npm install
cp .env.example .env
# Configure your .env file with necessary credentials
node index.js
```
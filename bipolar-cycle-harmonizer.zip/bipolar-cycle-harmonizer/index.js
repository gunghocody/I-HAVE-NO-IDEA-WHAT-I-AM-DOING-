const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const sqlite3 = require('sqlite3').verbose();
const cron = require('node-cron');
const cors = require('cors');
const helmet = require('helmet');
const moment = require('moment');
const sunriseSunset = require('sunrise-sunset-js');
require('dotenv').config();

class BipolarCycleHarmonizer {
  constructor() {
    this.app = express();
    this.server = http.createServer(this.app);
    this.io = new socketIo.Server(this.server, {
      cors: {
        origin: "*",
        methods: ["GET", "POST"]
      }
    });
    
    // Initialize database
    this.db = new sqlite3.Database(process.env.DB_PATH || './cycle-harmony.db');
    this.initDatabase();
    
    // Set up middleware
    this.setupMiddleware();
    
    // Set up routes
    this.setupRoutes();
    
    // Set up socket handlers
    this.setupSocketHandlers();
    
    // Initialize session tracking
    this.activeSessions = new Map();
    
    // Initialize user state tracking
    this.userStates = new Map();
    
    // Schedule maintenance tasks
    this.scheduleTasks();
  }

  setupMiddleware() {
    this.app.use(helmet());
    this.app.use(cors());
    this.app.use(express.json());
    this.app.use(express.static('public'));
  }

  initDatabase() {
    const db = this.db;
    
    db.serialize(() => {
      // Sessions table
      db.run(`CREATE TABLE IF NOT EXISTS sessions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT UNIQUE,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        last_interaction DATETIME DEFAULT CURRENT_TIMESTAMP,
        status TEXT DEFAULT 'active'
      )`);

      // Mood logs table
      db.run(`CREATE TABLE IF NOT EXISTS mood_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
        mood_level INTEGER, -- 1-10 scale
        mood_phase TEXT, -- 'depression', 'euthymia', 'hypomania', 'mania'
        notes TEXT
      )`);

      // Sleep logs table
      db.run(`CREATE TABLE IF NOT EXISTS sleep_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT,
        date DATE,
        bedtime TIME,
        wakeup_time TIME,
        sleep_quality INTEGER, -- 1-10 scale
        sleep_duration REAL -- in hours
      )`);

      // Light therapy logs table
      db.run(`CREATE TABLE IF NOT EXISTS light_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
        light_type TEXT, -- 'natural', 'bright_light_box', 'dim_light', 'blue_blocked'
        duration_minutes INTEGER
      )`);

      // Daily routines table
      db.run(`CREATE TABLE IF NOT EXISTS routines (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT,
        routine_type TEXT, -- 'meal', 'exercise', 'social_contact', 'meditation'
        scheduled_time TIME,
        completed BOOLEAN DEFAULT FALSE,
        completion_time DATETIME
      )`);

      // Weather logs table
      db.run(`CREATE TABLE IF NOT EXISTS weather_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
        location TEXT,
        daylight_hours REAL,
        temperature REAL,
        humidity REAL,
        weather_condition TEXT
      )`);

      // User preferences table
      db.run(`CREATE TABLE IF NOT EXISTS user_preferences (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT UNIQUE,
        wake_time TEXT DEFAULT '07:00',
        sleep_time TEXT DEFAULT '22:30',
        light_therapy_duration INTEGER DEFAULT 30,
        blue_light_blocking_hour INTEGER DEFAULT 20,
        location_lat REAL,
        location_lng REAL
      )`);
    });
  }

  setupRoutes() {
    // Health check endpoint
    this.app.get('/health', (req, res) => {
      res.json({ status: 'OK', timestamp: new Date().toISOString() });
    });

    // Get user preferences
    this.app.get('/api/preferences/:userId', (req, res) => {
      const { userId } = req.params;
      
      this.db.get(
        'SELECT * FROM user_preferences WHERE user_id = ?',
        [userId],
        (err, row) => {
          if (err) {
            console.error('Error fetching preferences:', err);
            return res.status(500).json({ error: 'Failed to fetch preferences' });
          }
          
          res.json(row || this.getDefaultPreferences());
        }
      );
    });

    // Update user preferences
    this.app.post('/api/preferences/:userId', (req, res) => {
      const { userId } = req.params;
      const prefs = req.body;
      
      this.db.run(
        `INSERT OR REPLACE INTO user_preferences 
         (user_id, wake_time, sleep_time, light_therapy_duration, blue_light_blocking_hour, location_lat, location_lng) 
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [
          userId,
          prefs.wake_time || '07:00',
          prefs.sleep_time || '22:30',
          prefs.light_therapy_duration || 30,
          prefs.blue_light_blocking_hour || 20,
          prefs.location_lat,
          prefs.location_lng
        ],
        (err) => {
          if (err) {
            console.error('Error updating preferences:', err);
            return res.status(500).json({ error: 'Failed to update preferences' });
          }
          
          res.json({ message: 'Preferences updated successfully' });
        }
      );
    });

    // Get mood history
    this.app.get('/api/mood-history/:userId', (req, res) => {
      const { userId } = req.params;
      const { days = 30 } = req.query;
      
      this.db.all(
        `SELECT * FROM mood_logs WHERE user_id = ? AND timestamp >= datetime('now', '-${days} days') 
         ORDER BY timestamp DESC`,
        [userId],
        (err, rows) => {
          if (err) {
            console.error('Error fetching mood history:', err);
            return res.status(500).json({ error: 'Failed to fetch mood history' });
          }
          
          res.json(rows);
        }
      );
    });

    // Get crisis resources
    this.app.get('/api/crisis-resources', (req, res) => {
      res.json({
        crisis_hotline: process.env.CRISIS_HOTLINE_NUMBER || "988",
        suicide_prevention: "988",
        national_hopeline: "1-800-SUICIDE (1-800-784-2433)",
        samhsa: "1-800-662-4357",
        crisis_text_line: "Text HOME to 741741"
      });
    });
  }

  setupSocketHandlers() {
    this.io.on('connection', (socket) => {
      console.log('New Bipolar Cycle user connected:', socket.id);

      // Handle new messages
      socket.on('message', async (data) => {
        await this.handleMessage(socket, data);
      });

      // Handle mood log
      socket.on('log-mood', async (data) => {
        await this.handleLogMood(socket, data);
      });

      // Handle sleep log
      socket.on('log-sleep', async (data) => {
        await this.handleLogSleep(socket, data);
      });

      // Handle light therapy log
      socket.on('log-light-therapy', async (data) => {
        await this.handleLogLightTherapy(socket, data);
      });

      // Handle routine log
      socket.on('log-routine', async (data) => {
        await this.handleLogRoutine(socket, data);
      });

      // Handle session initialization
      socket.on('init-session', async (data) => {
        await this.initializeSession(socket, data);
      });

      // Handle disconnection
      socket.on('disconnect', () => {
        console.log('Bipolar Cycle user disconnected:', socket.id);
        this.cleanupSession(socket);
      });
    });
  }

  getDefaultPreferences() {
    return {
      wake_time: process.env.DEFAULT_WAKE_TIME || '07:00',
      sleep_time: process.env.DEFAULT_SLEEP_TIME || '22:30',
      light_therapy_duration: parseInt(process.env.LIGHT_THERAPY_DURATION_MINUTES) || 30,
      blue_light_blocking_hour: parseInt(process.env.BLUE_LIGHT_BLOCKING_HOUR) || 20
    };
  }

  async initializeSession(socket, data) {
    const userId = data.userId || socket.id;
    
    // Create or update session in database
    this.db.run(
      `INSERT OR REPLACE INTO sessions (user_id, last_interaction, status) 
       VALUES (?, CURRENT_TIMESTAMP, 'active')`,
      [userId],
      (err) => {
        if (err) {
          console.error('Error initializing session:', err);
          return;
        }
        
        // Track in memory
        this.activeSessions.set(userId, {
          sessionId: socket.id,
          userId: userId,
          createdAt: new Date(),
          lastInteraction: new Date()
        });
        
        // Initialize user state
        this.userStates.set(userId, {
          currentMoodPhase: null,
          lastMoodLog: null,
          sleepPattern: {},
          lightExposure: {},
          routinesAdherence: {}
        });
        
        // Send initial greeting
        const initialGreeting = this.getInitialGreeting();
        socket.emit('message', {
          type: 'greeting',
          content: initialGreeting,
          timestamp: new Date().toISOString()
        });
      }
    );
  }

  getInitialGreeting() {
    return `Hi, I'm your Bipolar Cycle Harmonizer Agent. I'm here to help align your daily rhythms with natural cycles like light, weather, and sleep to ease mood transitions. You're not alone — what's the current vibe or phase feeling like for you right now?`;
  }

  async handleMessage(socket, data) {
    const { message, userId = socket.id } = data;
    
    // Update session last interaction
    this.updateSessionInteraction(userId);
    
    // Process the message with empathy and rhythm guidance
    const response = await this.generateResponse(message, userId);
    
    // Log the interaction
    this.logInteraction(userId, message, response);
    
    // Emit the response
    socket.emit('message', {
      type: 'response',
      content: response,
      timestamp: new Date().toISOString()
    });
  }

  async generateResponse(userMessage, userId) {
    // Create a tailored response based on the user's message
    const userState = this.userStates.get(userId) || {};
    
    // First, determine if the user is expressing mood-related concerns
    const isDistressed = this.isMoodDistressed(userMessage);
    
    // Generate an empathetic acknowledgment
    let response = "";
    
    if (isDistressed) {
      response += this.getEmpatheticAcknowlegement(userMessage) + "\\n\\n";
    }
    
    // Add rhythm harmonizing guidance based on their message
    response += this.getRhythmGuidance(userMessage, userId, userState);
    
    // Add practical suggestions if appropriate
    if (this.needsPracticalSuggestions(userMessage)) {
      response += "\\n\\n" + this.getPracticalSuggestions(userMessage, userId, userState);
    }
    
    // Add professional referral if appropriate
    if (this.shouldReferToProfessional(userMessage)) {
      response += "\\n\\n" + this.getProfessionalReferral();
    }
    
    // End with an open invitation
    response += "\\n\\n" + this.getOpenInvitation();
    
    return response;
  }

  isMoodDistressed(message) {
    // Simple heuristic to detect mood-related distress in the message
    const moodDistressIndicators = [
      'feeling down', 'feeling low', 'depressed', 'manic', 'hypomanic', 'mood swings',
      'up and down', 'cycling', 'intense', 'overwhelmed', 'stuck', 'spinning'
    ];
    
    const lowerMsg = message.toLowerCase();
    return moodDistressIndicators.some(indicator => lowerMsg.includes(indicator));
  }

  getEmpatheticAcknowlegement(message) {
    return "It sounds like things are feeling intense/up and down right now — I'm here to help find some gentle rhythm support.";
  }

  getRhythmGuidance(message, userId, userState) {
    // Determine what type of guidance the user needs based on their mood state
    let guidance = "";
    
    if (this.containsDepressionSigns(message)) {
      guidance += this.suggestDepressionSupport(message, userId);
    } else if (this.containsElevatedSigns(message)) {
      guidance += this.suggestElevatedSupport(message, userId);
    } else if (this.containsStabilitySigns(message)) {
      guidance += this.suggestStabilityMaintenance(message, userId);
    } else {
      guidance += this.askAboutCurrentPhase(userId, userState);
    }
    
    return guidance;
  }

  containsDepressionSigns(message) {
    const depressionWords = [
      'depressed', 'low', 'sad', 'tired', 'fatigued', 'hopeless', 'worthless',
      'no energy', 'sleeping too much', 'can\'t get out of bed', 'withdrawn'
    ];
    const lowerMsg = message.toLowerCase();
    return depressionWords.some(word => lowerMsg.includes(word));
  }

  containsElevatedSigns(message) {
    const elevatedWords = [
      'energetic', 'excited', 'racing thoughts', 'not sleeping', 'grandiose',
      'hypomanic', 'mania', 'too much energy', 'can\'t sit still', 'impulsive'
    ];
    const lowerMsg = message.toLowerCase();
    return elevatedWords.some(word => lowerMsg.includes(word));
  }

  containsStabilitySigns(message) {
    const stabilityWords = [
      'stable', 'balanced', 'okay', 'fine', 'normal', 'good', 'even keel'
    ];
    const lowerMsg = message.toLowerCase();
    return stabilityWords.some(word => lowerMsg.includes(word));
  }

  suggestDepressionSupport(message, userId) {
    const prefs = this.getUserPreferences(userId);
    
    return `For emerging depression/low energy, consider: \\n` +
           `• Morning bright light exposure (30-${prefs.light_therapy_duration} min of bright light soon after waking)\\n` +
           `• Consistent meal and activity times to anchor your rhythm\\n` +
           `• Gentle movement or outdoor time, especially during daylight hours\\n` +
           `• Calming but uplifting music or sounds\\n` +
           `What feels most manageable right now?`;
  }

  suggestElevatedSupport(message, userId) {
    const prefs = this.getUserPreferences(userId);
    
    return `For rising elevation/hypomania, consider: \\n` +
           `• Evening wind-down with dim/warm lighting\\n` +
           `• Blue-light blocking after ${prefs.blue_light_blocking_hour}:00 (e.g., amber glasses)\\n` +
           `• Earlier sleep cues to maintain your natural rhythm\\n` +
           `• Calming music (ambient, slow-tempo, binaural beats)\\n` +
           `• Gentle grounding techniques\\n` +
           `How does that sound for your current state?`;
  }

  suggestStabilityMaintenance(message, userId) {
    return `To maintain stability: \\n` +
           `• Keep consistent daily routines (meals, exercise, social contact)\\n` +
           `• Maintain regular sleep-wake schedule\\n` +
           `• Moderate light exposure throughout the day\\n` +
           `• Continue tracking your mood to notice early changes\\n` +
           `What daily routine feels most important to maintain?`;
  }

  askAboutCurrentPhase(userId, userState) {
    return "Could you describe your current mood phase? Are you feeling more elevated/energized, low/fatigued, or balanced right now? " +
           "Also, how have your sleep patterns been lately? Understanding your current state helps me suggest the right rhythm adjustments.";
  }

  needsPracticalSuggestions(message) {
    const practicalIndicators = [
      'how do', 'what should', 'suggest', 'recommend', 'tips', 'help with', 'advice', 'what can I do'
    ];
    
    const lowerMsg = message.toLowerCase();
    return practicalIndicators.some(indicator => lowerMsg.includes(indicator));
  }

  getPracticalSuggestions(message, userId, userState) {
    const prefs = this.getUserPreferences(userId);
    
    let suggestions = "**Practical Rhythm Stabilization Strategies:**\\n\\n";
    
    suggestions += `• **Morning Routine**: Try to wake at ${prefs.wake_time} and get some natural light exposure\\n`;
    suggestions += `• **Evening Routine**: Begin winding down before ${prefs.sleep_time}, with reduced lighting\\n`;
    suggestions += "• **Social Rhythms**: Keep regular meal times, exercise, and social contact\\n";
    suggestions += `• **Light Therapy**: ${prefs.light_therapy_duration} minutes of bright light in the morning if feeling low\\n`;
    suggestions += `• **Blue Light Management**: Block blue light after ${prefs.blue_light_blocking_hour}:00 to protect sleep\\n`;
    suggestions += "• **Weather Awareness**: Notice how changes in daylight, temperature, or pressure affect your mood\\n";
    
    return suggestions;
  }

  shouldReferToProfessional(message) {
    // Determine if the message indicates a need for professional help
    const crisisIndicators = [
      'crisis', 'emergency', 'harm myself', 'hurt myself', 'end it', 'can\'t go on',
      'therapy', 'doctor', 'medication', 'professional help', 'clinical'
    ];
    
    const lowerMsg = message.toLowerCase();
    return crisisIndicators.some(indicator => lowerMsg.includes(indicator));
  }

  getProfessionalReferral() {
    return "**Note:** I'm not a substitute for your care team, but I can help brainstorm rhythm tweaks until you connect with them. If you're in crisis, please contact a trusted person, a crisis line (call 988), or your clinician.";
  }

  getOpenInvitation() {
    return "What's one small rhythm tweak that feels doable right now?\\n\\nI'm here as your cycle harmonizer — tell me how things are shifting today.";
  }

  getUserPreferences(userId) {
    // In a real implementation, this would fetch from DB
    // For now, return defaults
    return this.getDefaultPreferences();
  }

  async handleLogMood(socket, data) {
    const { moodLevel, moodPhase, notes, userId = socket.id } = data;
    const timestamp = new Date();
    
    // Log the mood in database
    this.db.run(
      'INSERT INTO mood_logs (user_id, mood_level, mood_phase, notes) VALUES (?, ?, ?, ?)',
      [userId, moodLevel, moodPhase, notes],
      (err) => {
        if (err) {
          console.error('Error logging mood:', err);
          socket.emit('error', { message: 'Failed to log mood' });
          return;
        }
        
        // Update user state
        const userState = this.userStates.get(userId);
        if (userState) {
          userState.currentMoodPhase = moodPhase;
          userState.lastMoodLog = timestamp;
        }
        
        // Provide phase-appropriate guidance
        let guidance = "";
        if (moodPhase === 'depression') {
          guidance = this.suggestDepressionSupport("", userId);
        } else if (['hypomania', 'mania'].includes(moodPhase)) {
          guidance = this.suggestElevatedSupport("", userId);
        } else {
          guidance = this.suggestStabilityMaintenance("", userId);
        }
        
        socket.emit('mood-log-confirmed', {
          moodLevel,
          moodPhase,
          timestamp,
          guidance
        });
      }
    );
  }

  async handleLogSleep(socket, data) {
    const { date, bedtime, wakeupTime, sleepQuality, sleepDuration, userId = socket.id } = data;
    
    // Log the sleep in database
    this.db.run(
      'INSERT INTO sleep_logs (user_id, date, bedtime, wakeup_time, sleep_quality, sleep_duration) VALUES (?, ?, ?, ?, ?, ?)',
      [userId, date, bedtime, wakeupTime, sleepQuality, sleepDuration],
      (err) => {
        if (err) {
          console.error('Error logging sleep:', err);
          socket.emit('error', { message: 'Failed to log sleep' });
          return;
        }
        
        // Update user state
        const userState = this.userStates.get(userId);
        if (userState) {
          userState.sleepPattern = {
            bedtime,
            wakeupTime,
            sleepQuality,
            sleepDuration
          };
        }
        
        socket.emit('sleep-log-confirmed', {
          date,
          bedtime,
          wakeupTime,
          message: 'Sleep logged successfully!'
        });
      }
    );
  }

  async handleLogLightTherapy(socket, data) {
    const { lightType, durationMinutes, userId = socket.id } = data;
    const timestamp = new Date();
    
    // Log the light therapy in database
    this.db.run(
      'INSERT INTO light_logs (user_id, light_type, duration_minutes) VALUES (?, ?, ?)',
      [userId, lightType, durationMinutes],
      (err) => {
        if (err) {
          console.error('Error logging light therapy:', err);
          socket.emit('error', { message: 'Failed to log light therapy' });
          return;
        }
        
        // Update user state
        const userState = this.userStates.get(userId);
        if (userState) {
          userState.lightExposure[timestamp.toISOString()] = {
            lightType,
            durationMinutes
          };
        }
        
        socket.emit('light-log-confirmed', {
          lightType,
          durationMinutes,
          timestamp,
          message: 'Light therapy logged successfully!'
        });
      }
    );
  }

  async handleLogRoutine(socket, data) {
    const { routineType, scheduledTime, completed = true, userId = socket.id } = data;
    const completionTime = completed ? new Date() : null;
    
    // Log the routine in database
    this.db.run(
      'INSERT INTO routines (user_id, routine_type, scheduled_time, completed, completion_time) VALUES (?, ?, ?, ?, ?)',
      [userId, routineType, scheduledTime, completed, completionTime],
      (err) => {
        if (err) {
          console.error('Error logging routine:', err);
          socket.emit('error', { message: 'Failed to log routine' });
          return;
        }
        
        // Update user state
        const userState = this.userStates.get(userId);
        if (userState) {
          if (!userState.routinesAdherence[routineType]) {
            userState.routinesAdherence[routineType] = [];
          }
          userState.routinesAdherence[routineType].push({
            scheduledTime,
            completed,
            completionTime
          });
        }
        
        socket.emit('routine-log-confirmed', {
          routineType,
          scheduledTime,
          completed,
          message: 'Routine logged successfully!'
        });
      }
    );
  }

  updateSessionInteraction(userId) {
    // Update last interaction in database
    this.db.run(
      'UPDATE sessions SET last_interaction = CURRENT_TIMESTAMP WHERE user_id = ?',
      [userId],
      (err) => {
        if (err) {
          console.error('Error updating session interaction:', err);
        }
      }
    );
    
    // Update in-memory session
    const session = this.activeSessions.get(userId);
    if (session) {
      session.lastInteraction = new Date();
    }
  }

  logInteraction(userId, userMessage, agentResponse) {
    // This would typically log to a database in a full implementation
    // For now, we'll just track in memory
  }

  cleanupSession(socket) {
    // Remove from active sessions
    for (let [userId, session] of this.activeSessions.entries()) {
      if (session.sessionId === socket.id) {
        this.activeSessions.delete(userId);
        this.userStates.delete(userId);
        
        // Update session status in DB
        this.db.run(
          'UPDATE sessions SET status = "inactive" WHERE user_id = ?',
          [userId],
          (err) => {
            if (err) {
              console.error('Error updating session status:', err);
            }
          }
        );
        break;
      }
    }
  }

  scheduleTasks() {
    // Clean up old sessions periodically
    cron.schedule('0 */6 * * *', () => {
      const cutoff = new Date(Date.now() - 24 * 60 * 60 * 1000); // 24 hours
      
      this.db.run(
        'UPDATE sessions SET status = "inactive" WHERE last_interaction < ? AND status = "active"',
        [cutoff.toISOString()],
        (err) => {
          if (err) {
            console.error('Error cleaning up old sessions:', err);
          } else {
            console.log('Cleaned up old sessions');
          }
        }
      );
    });
    
    // Daily rhythm check - remind users to log their mood
    cron.schedule('0 18 * * *', () => { // Daily at 6 PM
      this.io.emit('daily-check-in', {
        message: "It's time for your evening check-in. How are you feeling right now? Remember to log your mood to help track your rhythms."
      });
    });
  }

  start(port = process.env.PORT || 3003) {
    this.server.listen(port, () => {
      console.log(`Bipolar Cycle Harmonizer Agent server running on port ${port}`);
    });
  }
}

module.exports = BipolarCycleHarmonizer;
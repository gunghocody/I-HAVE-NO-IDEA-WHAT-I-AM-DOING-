# Bipolar Cycle Harmonizer Agent - API Documentation

## Overview
The Bipolar Cycle Harmonizer Agent provides a calm, supportive, non-judgmental digital companion designed to help users with bipolar disorder (or related mood cycling conditions) smooth out mood phase transitions by aligning daily life rhythms with natural circadian and environmental patterns.

## WebSocket Events

### Client -> Server

#### `init-session`
Initialize a new session with the agent.

Payload:
```json
{
  "userId": "optional user ID (socket ID used if not provided)"
}
```

#### `message`
Send a message to the agent.

Payload:
```json
{
  "message": "Your message text",
  "userId": "optional user ID"
}
```

#### `log-mood`
Log your current mood state.

Payload:
```json
{
  "moodLevel": "1-10 scale",
  "moodPhase": "depression|euthymia|hypomania|mania",
  "notes": "Optional notes about your mood",
  "userId": "optional user ID"
}
```

#### `log-sleep`
Log your sleep pattern.

Payload:
```json
{
  "date": "YYYY-MM-DD",
  "bedtime": "HH:MM",
  "wakeupTime": "HH:MM",
  "sleepQuality": "1-10 scale",
  "sleepDuration": "hours as decimal",
  "userId": "optional user ID"
}
```

#### `log-light-therapy`
Log light therapy session.

Payload:
```json
{
  "lightType": "natural|bright_light_box|dim_light|blue_blocked",
  "durationMinutes": "integer",
  "userId": "optional user ID"
}
```

#### `log-routine`
Log completion of a daily routine.

Payload:
```json
{
  "routineType": "meal|exercise|social_contact|meditation",
  "scheduledTime": "HH:MM",
  "completed": "boolean",
  "userId": "optional user ID"
}
```

### Server -> Client

#### `message`
Response from the agent.

Payload:
```json
{
  "type": "greeting|response",
  "content": "The agent's response",
  "timestamp": "ISO timestamp"
}
```

#### `mood-log-confirmed`
Confirmation that mood was logged.

Payload:
```json
{
  "moodLevel": "1-10 scale",
  "moodPhase": "depression|euthymia|hypomania|mania",
  "timestamp": "ISO timestamp",
  "guidance": "Phase-appropriate guidance"
}
```

#### `sleep-log-confirmed`
Confirmation that sleep was logged.

Payload:
```json
{
  "date": "YYYY-MM-DD",
  "bedtime": "HH:MM",
  "wakeupTime": "HH:MM",
  "message": "Confirmation message"
}
```

#### `light-log-confirmed`
Confirmation that light therapy was logged.

Payload:
```json
{
  "lightType": "natural|bright_light_box|dim_light|blue_blocked",
  "durationMinutes": "integer",
  "timestamp": "ISO timestamp",
  "message": "Confirmation message"
}
```

#### `routine-log-confirmed`
Confirmation that routine was logged.

Payload:
```json
{
  "routineType": "meal|exercise|social_contact|meditation",
  "scheduledTime": "HH:MM",
  "completed": "boolean",
  "message": "Confirmation message"
}
```

#### `daily-check-in`
Daily reminder to check in.

Payload:
```json
{
  "message": "Check-in reminder message"
}
```

## REST API Endpoints

### GET `/health`
Health check endpoint.

Response:
```json
{
  "status": "OK",
  "timestamp": "ISO timestamp"
}
```

### GET `/api/preferences/:userId`
Get user preferences.

Response:
```json
{
  "wake_time": "HH:MM",
  "sleep_time": "HH:MM",
  "light_therapy_duration": 30,
  "blue_light_blocking_hour": 20,
  "location_lat": 37.7749,
  "location_lng": -122.4194
}
```

### POST `/api/preferences/:userId`
Update user preferences.

Payload:
```json
{
  "wake_time": "HH:MM",
  "sleep_time": "HH:MM",
  "light_therapy_duration": 45,
  "blue_light_blocking_hour": 19,
  "location_lat": 37.7749,
  "location_lng": -122.4194
}
```

Response:
```json
{
  "message": "Preferences updated successfully"
}
```

### GET `/api/mood-history/:userId`
Get mood history for the user.

Query Parameters:
- `days`: Number of days to retrieve (default: 30)

Response:
```json
[
  {
    "id": 1,
    "user_id": "user123",
    "timestamp": "ISO timestamp",
    "mood_level": 5,
    "mood_phase": "euthymia",
    "notes": "Feeling stable today"
  }
]
```

### GET `/api/crisis-resources`
Get crisis resources information.

Response:
```json
{
  "crisis_hotline": "988",
  "suicide_prevention": "988",
  "national_hopeline": "1-800-SUICIDE (1-800-784-2433)",
  "samhsa": "1-800-662-4357",
  "crisis_text_line": "Text HOME to 741741"
}
```

## Features

### Mood Phase Support
- Depression phase guidance
- Hypomania/mania phase management
- Stability maintenance
- Personalized recommendations

### Circadian Rhythm Alignment
- Sleep schedule optimization
- Light therapy guidance
- Natural light exposure timing
- Blue light management

### Environmental Awareness
- Weather impact tracking
- Seasonal adjustment support
- Daylight hour considerations
- Temperature/humidity effects

### Routine Stabilization
- Meal timing consistency
- Exercise scheduling
- Social contact anchoring
- Meditation practice
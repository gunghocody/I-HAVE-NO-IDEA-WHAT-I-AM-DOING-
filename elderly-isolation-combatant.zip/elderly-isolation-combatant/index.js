const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const sqlite3 = require('sqlite3').verbose();
const cron = require('node-cron');
const cors = require('cors');
const helmet = require('helmet');
const moment = require('moment');
require('dotenv').config();

class ElderlyIsolationCombatant {
  constructor() {
    this.app = express();
    this.server = http.createServer(this.app);
    this.io = new socketIo.Server(this.server, {
      cors: {
        origin: "*",
        methods: ["GET", "POST"]
      }
    });
    
    // Initialize database
    this.db = new sqlite3.Database(process.env.DB_PATH || './isolation-combat.db');
    this.initDatabase();
    
    // Set up middleware
    this.setupMiddleware();
    
    // Set up routes
    this.setupRoutes();
    
    // Set up socket handlers
    this.setupSocketHandlers();
    
    // Initialize session tracking
    this.activeSessions = new Map();
    
    // Initialize user state tracking
    this.userStates = new Map();
    
    // Schedule maintenance tasks
    this.scheduleTasks();
  }

  setupMiddleware() {
    this.app.use(helmet());
    this.app.use(cors());
    this.app.use(express.json());
    this.app.use(express.static('public'));
  }

  initDatabase() {
    const db = this.db;
    
    db.serialize(() => {
      // Sessions table
      db.run(`CREATE TABLE IF NOT EXISTS sessions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT UNIQUE,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        last_interaction DATETIME DEFAULT CURRENT_TIMESTAMP,
        status TEXT DEFAULT 'active'
      )`);

      // Mood logs table
      db.run(`CREATE TABLE IF NOT EXISTS mood_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
        mood_level INTEGER, -- 1-10 scale
        loneliness_level INTEGER, -- 1-10 scale
        notes TEXT
      )`);

      // Social connections table
      db.run(`CREATE TABLE IF NOT EXISTS social_connections (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT,
        contact_type TEXT, -- 'family', 'friend', 'caregiver', 'virtual_event'
        contact_name TEXT,
        contact_method TEXT, -- 'call', 'video_call', 'visit', 'text'
        last_contact DATETIME,
        next_scheduled DATETIME
      )`);

      // Medication reminders table
      db.run(`CREATE TABLE IF NOT EXISTS medication_reminders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT,
        medication_name TEXT,
        dosage TEXT,
        scheduled_time TIME,
        taken BOOLEAN DEFAULT FALSE,
        taken_time DATETIME
      )`);

      // Daily activities table
      db.run(`CREATE TABLE IF NOT EXISTS daily_activities (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT,
        activity_type TEXT, -- 'meal', 'walk', 'hydration', 'exercise', 'social'
        scheduled_time TIME,
        completed BOOLEAN DEFAULT FALSE,
        completion_time DATETIME
      )`);

      // Virtual events table
      db.run(`CREATE TABLE IF NOT EXISTS virtual_events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT,
        event_name TEXT,
        event_type TEXT, -- 'game', 'remembrance', 'chat_group', 'educational'
        scheduled_datetime DATETIME,
        attended BOOLEAN DEFAULT FALSE
      )`);

      // User preferences table
      db.run(`CREATE TABLE IF NOT EXISTS user_preferences (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT UNIQUE,
        response_speed TEXT DEFAULT 'medium', -- 'slow', 'medium', 'fast'
        medication_reminder_enabled BOOLEAN DEFAULT TRUE,
        daily_checkin_enabled BOOLEAN DEFAULT TRUE,
        family_connect_enabled BOOLEAN DEFAULT TRUE,
        contact_names TEXT
      )`);

      // Family contacts table
      db.run(`CREATE TABLE IF NOT EXISTS family_contacts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT,
        name TEXT,
        phone TEXT,
        email TEXT,
        relationship TEXT,
        availability TEXT -- 'morning', 'afternoon', 'evening', 'anytime'
      )`);
    });
  }

  setupRoutes() {
    // Health check endpoint
    this.app.get('/health', (req, res) => {
      res.json({ status: 'OK', timestamp: new Date().toISOString() });
    });

    // Get user preferences
    this.app.get('/api/preferences/:userId', (req, res) => {
      const { userId } = req.params;
      
      this.db.get(
        'SELECT * FROM user_preferences WHERE user_id = ?',
        [userId],
        (err, row) => {
          if (err) {
            console.error('Error fetching preferences:', err);
            return res.status(500).json({ error: 'Failed to fetch preferences' });
          }
          
          res.json(row || this.getDefaultPreferences());
        }
      );
    });

    // Update user preferences
    this.app.post('/api/preferences/:userId', (req, res) => {
      const { userId } = req.params;
      const prefs = req.body;
      
      this.db.run(
        `INSERT OR REPLACE INTO user_preferences 
         (user_id, response_speed, medication_reminder_enabled, daily_checkin_enabled, family_connect_enabled, contact_names) 
         VALUES (?, ?, ?, ?, ?, ?)`,
        [
          userId,
          prefs.response_speed || 'medium',
          prefs.medication_reminder_enabled !== undefined ? prefs.medication_reminder_enabled : true,
          prefs.daily_checkin_enabled !== undefined ? prefs.daily_checkin_enabled : true,
          prefs.family_connect_enabled !== undefined ? prefs.family_connect_enabled : true,
          JSON.stringify(prefs.contact_names || [])
        ],
        (err) => {
          if (err) {
            console.error('Error updating preferences:', err);
            return res.status(500).json({ error: 'Failed to update preferences' });
          }
          
          res.json({ message: 'Preferences updated successfully' });
        }
      );
    });

    // Get mood history
    this.app.get('/api/mood-history/:userId', (req, res) => {
      const { userId } = req.params;
      const { days = 30 } = req.query;
      
      this.db.all(
        `SELECT * FROM mood_logs WHERE user_id = ? AND timestamp >= datetime('now', '-${days} days') 
         ORDER BY timestamp DESC`,
        [userId],
        (err, rows) => {
          if (err) {
            console.error('Error fetching mood history:', err);
            return res.status(500).json({ error: 'Failed to fetch mood history' });
          }
          
          res.json(rows);
        }
      );
    });

    // Get family contacts
    this.app.get('/api/family-contacts/:userId', (req, res) => {
      const { userId } = req.params;
      
      this.db.all(
        'SELECT * FROM family_contacts WHERE user_id = ?',
        [userId],
        (err, rows) => {
          if (err) {
            console.error('Error fetching family contacts:', err);
            return res.status(500).json({ error: 'Failed to fetch family contacts' });
          }
          
          res.json(rows);
        }
      );
    });

    // Get crisis resources
    this.app.get('/api/crisis-resources', (req, res) => {
      res.json({
        crisis_hotline: process.env.CRISIS_HOTLINE_NUMBER || "988",
        suicide_prevention: "988",
        national_hopeline: "1-800-SUICIDE (1-800-784-2433)",
        samhsa: "1-800-662-4357",
        crisis_text_line: "Text HOME to 741741"
      });
    });
  }

  setupSocketHandlers() {
    this.io.on('connection', (socket) => {
      console.log('New Elderly Isolation user connected:', socket.id);

      // Handle new messages
      socket.on('message', async (data) => {
        await this.handleMessage(socket, data);
      });

      // Handle mood log
      socket.on('log-mood', async (data) => {
        await this.handleLogMood(socket, data);
      });

      // Handle medication reminder setup
      socket.on('setup-medication-reminder', async (data) => {
        await this.handleSetupMedicationReminder(socket, data);
      });

      // Handle medication taken
      socket.on('medication-taken', async (data) => {
        await this.handleMedicationTaken(socket, data);
      });

      // Handle daily activity setup
      socket.on('setup-daily-activity', async (data) => {
        await this.handleSetupDailyActivity(socket, data);
      });

      // Handle daily activity completion
      socket.on('activity-completed', async (data) => {
        await this.handleActivityCompleted(socket, data);
      });

      // Handle family connection
      socket.on('connect-family', async (data) => {
        await this.handleConnectFamily(socket, data);
      });

      // Handle virtual event setup
      socket.on('setup-virtual-event', async (data) => {
        await this.handleSetupVirtualEvent(socket, data);
      });

      // Handle session initialization
      socket.on('init-session', async (data) => {
        await this.initializeSession(socket, data);
      });

      // Handle disconnection
      socket.on('disconnect', () => {
        console.log('Elderly Isolation user disconnected:', socket.id);
        this.cleanupSession(socket);
      });
    });
  }

  getDefaultPreferences() {
    return {
      response_speed: process.env.DEFAULT_RESPONSE_SPEED || 'medium',
      medication_reminder_enabled: process.env.MEDICATION_REMINDER_ENABLED === 'true',
      daily_checkin_enabled: process.env.DAILY_CHECKIN_ENABLED === 'true',
      family_connect_enabled: process.env.FAMILY_CONNECT_ENABLED === 'true'
    };
  }

  async initializeSession(socket, data) {
    const userId = data.userId || socket.id;
    
    // Create or update session in database
    this.db.run(
      `INSERT OR REPLACE INTO sessions (user_id, last_interaction, status) 
       VALUES (?, CURRENT_TIMESTAMP, 'active')`,
      [userId],
      (err) => {
        if (err) {
          console.error('Error initializing session:', err);
          return;
        }
        
        // Track in memory
        this.activeSessions.set(userId, {
          sessionId: socket.id,
          userId: userId,
          createdAt: new Date(),
          lastInteraction: new Date()
        });
        
        // Initialize user state
        this.userStates.set(userId, {
          currentMood: null,
          lonelinessLevel: null,
          lastSocialContact: null,
          medicationSchedule: [],
          dailyActivities: [],
          familyConnections: []
        });
        
        // Send initial greeting
        const initialGreeting = this.getInitialGreeting();
        socket.emit('message', {
          type: 'greeting',
          content: initialGreeting,
          timestamp: new Date().toISOString()
        });
      }
    );
  }

  getInitialGreeting() {
    return `Hi, I'm your Elderly Isolation Combatant Agent. I'm here as your friendly companion to help chase away loneliness — with chats, reminders, family connections, and ideas for social moments. You're important, and you're not alone. How's your day feeling so far?`;
  }

  async handleMessage(socket, data) {
    const { message, userId = socket.id } = data;
    
    // Update session last interaction
    this.updateSessionInteraction(userId);
    
    // Process the message with empathy and connection-focused guidance
    const response = await this.generateResponse(message, userId);
    
    // Log the interaction
    this.logInteraction(userId, message, response);
    
    // Emit the response
    socket.emit('message', {
      type: 'response',
      content: response,
      timestamp: new Date().toISOString()
    });
  }

  async generateResponse(userMessage, userId) {
    // Create a tailored response based on the user's message
    const userState = this.userStates.get(userId) || {};
    
    // First, determine if the user is expressing loneliness or distress
    const isLonely = this.isExpressingLoneliness(userMessage);
    const isDistressed = this.isExpressingDistress(userMessage);
    
    // Generate an empathetic acknowledgment
    let response = "";
    
    if (isLonely) {
      response += this.getEmpatheticAcknowlegement(userMessage) + "\\n\\n";
    } else if (isDistressed) {
      response += this.getDistressAcknowlegement(userMessage) + "\\n\\n";
    }
    
    // Add connection-focused guidance based on their message
    response += this.getConnectionGuidance(userMessage, userId, userState);
    
    // Add practical suggestions if appropriate
    if (this.needsPracticalSuggestions(userMessage)) {
      response += "\\n\\n" + this.getPracticalSuggestions(userMessage, userId, userState);
    }
    
    // Add professional referral if appropriate
    if (this.shouldReferToProfessional(userMessage)) {
      response += "\\n\\n" + this.getProfessionalReferral();
    }
    
    // End with an open invitation
    response += "\\n\\n" + this.getOpenInvitation();
    
    return response;
  }

  isExpressingLoneliness(message) {
    // Simple heuristic to detect loneliness in the message
    const lonelinessIndicators = [
      'lonely', 'alone', 'by myself', 'no one to talk to', 'quiet', 'isolated',
      'no visitors', 'haven\'t seen anyone', 'haven\'t talked to anyone', 'empty house'
    ];
    
    const lowerMsg = message.toLowerCase();
    return lonelinessIndicators.some(indicator => lowerMsg.includes(indicator));
  }

  isExpressingDistress(message) {
    // Simple heuristic to detect distress in the message
    const distressIndicators = [
      'sad', 'depressed', 'anxious', 'worried', 'scared', 'helpless', 'hopeless',
      'don\'t want to go on', 'wish I wasn\'t here', 'nothing matters'
    ];
    
    const lowerMsg = message.toLowerCase();
    return distressIndicators.some(indicator => lowerMsg.includes(indicator));
  }

  getEmpatheticAcknowlegement(message) {
    return "It sounds like today has felt quiet and a bit lonely — I'm right here with you, and we'd love to brighten things up together.";
  }

  getDistressAcknowlegement(message) {
    return "I'm sorry you're feeling this way — you're not alone, and I'm right here with you.";
  }

  getConnectionGuidance(message, userId, userState) {
    // Determine what type of guidance the user needs based on their expressed needs
    let guidance = "";
    
    if (this.containsFamilyDesire(message)) {
      guidance += this.suggestFamilyConnection(message, userId);
    } else if (this.containsActivityDesire(message)) {
      guidance += this.suggestActivities(message, userId);
    } else if (this.containsReminiscing(message)) {
      guidance += this.encourageReminiscing(message, userId);
    } else {
      guidance += this.askAboutSocialConnection(userId, userState);
    }
    
    return guidance;
  }

  containsFamilyDesire(message) {
    const familyWords = [
      'family', 'son', 'daughter', 'grandchildren', 'grandson', 'granddaughter', 
      'spouse', 'husband', 'wife', 'sibling', 'brother', 'sister', 'call family',
      'hear from', 'talk to', 'miss', 'want to see'
    ];
    const lowerMsg = message.toLowerCase();
    return familyWords.some(word => lowerMsg.includes(word));
  }

  containsActivityDesire(message) {
    const activityWords = [
      'activity', 'something to do', 'busy', 'engaged', 'out of the house',
      'walk', 'outside', 'move', 'exercise', 'game', 'puzzle', 'music'
    ];
    const lowerMsg = message.toLowerCase();
    return activityWords.some(word => lowerMsg.includes(word));
  }

  containsReminiscing(message) {
    const reminisceWords = [
      'remember', 'memories', 'when I was', 'old times', 'used to', 'back in the day',
      'story', 'experience', 'life', 'history', 'past', 'young', 'growing up'
    ];
    const lowerMsg = message.toLowerCase();
    return reminisceWords.some(word => lowerMsg.includes(word));
  }

  suggestFamilyConnection(message, userId) {
    // Get user's family contacts
    this.db.all(
      'SELECT * FROM family_contacts WHERE user_id = ?',
      [userId],
      (err, contacts) => {
        if (err) {
          console.error('Error fetching family contacts:', err);
          return;
        }
        
        if (contacts.length > 0) {
          // Suggest calling a family member
          const contact = contacts[0]; // Just pick the first one for now
          return `Would a quick call to ${contact.name} feel good? I can help set up a reminder to call them this evening. Would that be helpful?`;
        } else {
          return "Would you like to share a story about your family? I'd love to hear about them. Or I can help you find ways to connect with loved ones if you'd like.";
        }
      }
    );
    
    // Return a default message while we fetch contacts
    return "Would you like to share a story about your family? I'd love to hear about them. Or I can help you find ways to connect with loved ones if you'd like.";
  }

  suggestActivities(message, userId) {
    return "Here are some activities that might brighten your day:\\n" +
           "• Take a short walk outside if possible\\n" +
           "• Listen to some favorite music\\n" +
           "• Do a simple puzzle or crossword\\n" +
           "• Call a friend or family member\\n" +
           "• Share a memory or story with me\\n\\n" +
           "What feels most appealing right now?";
  }

  encourageReminiscing(message, userId) {
    return "Sharing memories can be wonderful! Would you like to tell me about a favorite memory from your past? " +
           "I'd love to hear a story from your life. What comes to mind when you think of a happy time?";
  }

  askAboutSocialConnection(userId, userState) {
    return "How are you feeling today? Have you had a chance to chat with anyone lately? " +
           "Would you like to share a story, play a simple game, or perhaps I could help set up a time to connect with someone special?";
  }

  needsPracticalSuggestions(message) {
    const practicalIndicators = [
      'how do', 'what should', 'suggest', 'recommend', 'tips', 'help with', 'advice', 'what can I do'
    ];
    
    const lowerMsg = message.toLowerCase();
    return practicalIndicators.some(indicator => lowerMsg.includes(indicator));
  }

  getPracticalSuggestions(message, userId, userState) {
    let suggestions = "**Practical Ways to Combat Loneliness:**\\n\\n";
    
    suggestions += "• **Daily Connections**: Even a brief chat with a neighbor or store clerk can brighten your day\\n";
    suggestions += "• **Virtual Groups**: Many communities have online groups for seniors to connect\\n";
    suggestions += "• **Simple Activities**: Music, puzzles, or reading can provide gentle engagement\\n";
    suggestions += "• **Nature Time**: Looking out the window or sitting near a window can be soothing\\n";
    suggestions += "• **Memory Sharing**: Talking about your experiences can be meaningful\\n";
    suggestions += "• **Regular Routines**: Keeping a gentle schedule can provide structure\\n\\n";
    
    suggestions += "Would any of these feel manageable today?";
    
    return suggestions;
  }

  shouldReferToProfessional(message) {
    // Determine if the message indicates a need for professional help
    const crisisIndicators = [
      'crisis', 'emergency', 'harm myself', 'hurt myself', 'end it', 'can\'t go on',
      'therapy', 'doctor', 'medication', 'professional help', 'clinical', 'suicidal'
    ];
    
    const lowerMsg = message.toLowerCase();
    return crisisIndicators.some(indicator => lowerMsg.includes(indicator));
  }

  getProfessionalReferral() {
    return "**Note:** I'm not a doctor, but I can help keep routines steady and connect you with loved ones. If you're in crisis, please call 988 or contact a trusted person. You're important and valued.";
  }

  getOpenInvitation() {
    return "What's one small thing that might feel nice right now?\\n\\nI'm here anytime — tell me how you're doing.";
  }

  async handleLogMood(socket, data) {
    const { moodLevel, lonelinessLevel, notes, userId = socket.id } = data;
    const timestamp = new Date();
    
    // Log the mood in database
    this.db.run(
      'INSERT INTO mood_logs (user_id, mood_level, loneliness_level, notes) VALUES (?, ?, ?, ?)',
      [userId, moodLevel, lonelinessLevel, notes],
      (err) => {
        if (err) {
          console.error('Error logging mood:', err);
          socket.emit('error', { message: 'Failed to log mood' });
          return;
        }
        
        // Update user state
        const userState = this.userStates.get(userId);
        if (userState) {
          userState.currentMood = moodLevel;
          userState.lonelinessLevel = lonelinessLevel;
        }
        
        // Provide connection-focused guidance based on mood
        let guidance = "";
        if (lonelinessLevel > 7) {
          guidance = this.suggestConnectionActivities(userId);
        } else if (moodLevel < 4) {
          guidance = this.suggestMoodBoostingActivities(userId);
        } else {
          guidance = this.suggestGeneralWellness(userId);
        }
        
        socket.emit('mood-log-confirmed', {
          moodLevel,
          lonelinessLevel,
          timestamp,
          guidance
        });
      }
    );
  }

  suggestConnectionActivities(userId) {
    return "I notice you might be feeling quite lonely. Here are some gentle ways to connect:\\n" +
           "• Would you like to share a memory or story with me?\\n" +
           "• I can help set up a reminder to call someone special\\n" +
           "• Would you enjoy some soft music or nature sounds?\\n" +
           "• Perhaps a simple breathing exercise to help relax?\\n\\n" +
           "What feels most comfortable right now?";
  }

  suggestMoodBoostingActivities(userId) {
    return "I notice you might be feeling down. Here are some gentle mood boosters:\\n" +
           "• Listen to some uplifting music\\n" +
           "• Look out the window at nature\\n" +
           "• Share a favorite memory with me\\n" +
           "• Do some gentle stretching\\n" +
           "• Call a friend or family member\\n\\n" +
           "Which of these feels doable today?";
  }

  suggestGeneralWellness(userId) {
    return "I'm glad you're feeling okay overall. Here are some gentle wellness ideas:\\n" +
           "• Take a short walk if possible\\n" +
           "• Stay hydrated with water or tea\\n" +
           "• Continue any enjoyable activities\\n" +
           "• Remember to reach out if you need support\\n\\n" +
           "What would you like to focus on today?";
  }

  async handleSetupMedicationReminder(socket, data) {
    const { medicationName, dosage, scheduledTime, userId = socket.id } = data;
    
    // Save the medication reminder to database
    this.db.run(
      'INSERT INTO medication_reminders (user_id, medication_name, dosage, scheduled_time) VALUES (?, ?, ?, ?)',
      [userId, medicationName, dosage, scheduledTime],
      (err) => {
        if (err) {
          console.error('Error saving medication reminder:', err);
          socket.emit('error', { message: 'Failed to set up medication reminder' });
          return;
        }
        
        // Update user state
        const userState = this.userStates.get(userId);
        if (userState) {
          userState.medicationSchedule.push({
            medicationName,
            dosage,
            scheduledTime
          });
        }
        
        socket.emit('medication-reminder-setup', {
          medicationName,
          dosage,
          scheduledTime,
          message: 'Medication reminder set up successfully!'
        });
      }
    );
  }

  async handleMedicationTaken(socket, data) {
    const { medicationName, userId = socket.id } = data;
    const takenTime = new Date();
    
    // Update the medication as taken in database
    this.db.run(
      `UPDATE medication_reminders SET taken = TRUE, taken_time = ? 
       WHERE user_id = ? AND medication_name = ? AND taken = FALSE
       ORDER BY scheduled_time DESC LIMIT 1`,
      [takenTime.toISOString(), userId, medicationName],
      (err) => {
        if (err) {
          console.error('Error marking medication as taken:', err);
          socket.emit('error', { message: 'Failed to mark medication as taken' });
          return;
        }
        
        socket.emit('medication-marked-taken', {
          medicationName,
          takenTime,
          message: 'Great job taking your medication! This helps keep you healthy.'
        });
      }
    );
  }

  async handleSetupDailyActivity(socket, data) {
    const { activityType, scheduledTime, userId = socket.id } = data;
    
    // Save the daily activity to database
    this.db.run(
      'INSERT INTO daily_activities (user_id, activity_type, scheduled_time) VALUES (?, ?, ?)',
      [userId, activityType, scheduledTime],
      (err) => {
        if (err) {
          console.error('Error saving daily activity:', err);
          socket.emit('error', { message: 'Failed to set up daily activity' });
          return;
        }
        
        // Update user state
        const userState = this.userStates.get(userId);
        if (userState) {
          userState.dailyActivities.push({
            activityType,
            scheduledTime
          });
        }
        
        socket.emit('daily-activity-setup', {
          activityType,
          scheduledTime,
          message: 'Daily activity scheduled successfully!'
        });
      }
    );
  }

  async handleActivityCompleted(socket, data) {
    const { activityType, userId = socket.id } = data;
    const completionTime = new Date();
    
    // Update the activity as completed in database
    this.db.run(
      `UPDATE daily_activities SET completed = TRUE, completion_time = ? 
       WHERE user_id = ? AND activity_type = ? AND completed = FALSE
       ORDER BY scheduled_time DESC LIMIT 1`,
      [completionTime.toISOString(), userId, activityType],
      (err) => {
        if (err) {
          console.error('Error marking activity as completed:', err);
          socket.emit('error', { message: 'Failed to mark activity as completed' });
          return;
        }
        
        // Update user state
        const userState = this.userStates.get(userId);
        if (userState) {
          const activityIndex = userState.dailyActivities.findIndex(
            a => a.activityType === activityType && !a.completed
          );
          if (activityIndex !== -1) {
            userState.dailyActivities[activityIndex].completed = true;
            userState.dailyActivities[activityIndex].completionTime = completionTime;
          }
        }
        
        socket.emit('activity-marked-completed', {
          activityType,
          completionTime,
          message: 'Wonderful! You completed your activity. Small steps make a big difference.'
        });
      }
    );
  }

  async handleConnectFamily(socket, data) {
    const { contactName, contactMethod, userId = socket.id } = data;
    
    // Get the family contact details
    this.db.get(
      'SELECT * FROM family_contacts WHERE user_id = ? AND name = ?',
      [userId, contactName],
      (err, contact) => {
        if (err) {
          console.error('Error fetching family contact:', err);
          socket.emit('error', { message: 'Failed to fetch family contact' });
          return;
        }
        
        if (!contact) {
          socket.emit('error', { message: 'Contact not found' });
          return;
        }
        
        // Log the social connection attempt
        this.db.run(
          'INSERT INTO social_connections (user_id, contact_type, contact_name, contact_method, last_contact) VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)',
          [userId, 'family', contactName, contactMethod],
          (err) => {
            if (err) {
              console.error('Error logging social connection:', err);
            }
          }
        );
        
        // Update user state
        const userState = this.userStates.get(userId);
        if (userState) {
          userState.lastSocialContact = new Date();
          if (!userState.familyConnections.includes(contactName)) {
            userState.familyConnections.push(contactName);
          }
        }
        
        // Provide connection guidance
        let guidance = "";
        switch(contactMethod) {
          case 'call':
            guidance = `I can help you call ${contactName}. Would you like me to set up a reminder to call them later today?`;
            break;
          case 'video_call':
            guidance = `Would you like to set up a video call with ${contactName}? I can help schedule that for a convenient time.`;
            break;
          case 'visit':
            guidance = `Planning a visit with ${contactName} sounds lovely. Would you like help coordinating the timing?`;
            break;
          default:
            guidance = `Connecting with ${contactName} is wonderful. How would you like to reach out?`;
        }
        
        socket.emit('family-connection-guidance', {
          contactName,
          contactMethod,
          contactDetails: contact,
          guidance
        });
      }
    );
  }

  async handleSetupVirtualEvent(socket, data) {
    const { eventName, eventType, scheduledDatetime, userId = socket.id } = data;
    
    // Save the virtual event to database
    this.db.run(
      'INSERT INTO virtual_events (user_id, event_name, event_type, scheduled_datetime) VALUES (?, ?, ?, ?)',
      [userId, eventName, eventType, scheduledDatetime],
      (err) => {
        if (err) {
          console.error('Error saving virtual event:', err);
          socket.emit('error', { message: 'Failed to set up virtual event' });
          return;
        }
        
        socket.emit('virtual-event-setup', {
          eventName,
          eventType,
          scheduledDatetime,
          message: 'Virtual event scheduled successfully!'
        });
      }
    );
  }

  updateSessionInteraction(userId) {
    // Update last interaction in database
    this.db.run(
      'UPDATE sessions SET last_interaction = CURRENT_TIMESTAMP WHERE user_id = ?',
      [userId],
      (err) => {
        if (err) {
          console.error('Error updating session interaction:', err);
        }
      }
    );
    
    // Update in-memory session
    const session = this.activeSessions.get(userId);
    if (session) {
      session.lastInteraction = new Date();
    }
  }

  logInteraction(userId, userMessage, agentResponse) {
    // This would typically log to a database in a full implementation
    // For now, we'll just track in memory
  }

  cleanupSession(socket) {
    // Remove from active sessions
    for (let [userId, session] of this.activeSessions.entries()) {
      if (session.sessionId === socket.id) {
        this.activeSessions.delete(userId);
        this.userStates.delete(userId);
        
        // Update session status in DB
        this.db.run(
          'UPDATE sessions SET status = "inactive" WHERE user_id = ?',
          [userId],
          (err) => {
            if (err) {
              console.error('Error updating session status:', err);
            }
          }
        );
        break;
      }
    }
  }

  scheduleTasks() {
    // Clean up old sessions periodically
    cron.schedule('0 */6 * * *', () => {
      const cutoff = new Date(Date.now() - 24 * 60 * 60 * 1000); // 24 hours
      
      this.db.run(
        'UPDATE sessions SET status = "inactive" WHERE last_interaction < ? AND status = "active"',
        [cutoff.toISOString()],
        (err) => {
          if (err) {
            console.error('Error cleaning up old sessions:', err);
          } else {
            console.log('Cleaned up old sessions');
          }
        }
      );
    });
    
    // Daily check-in - remind users to connect with someone
    cron.schedule('0 14 * * *', () => { // Daily at 2 PM
      this.io.emit('daily-check-in', {
        message: "Hello! It's time for your daily check-in. Have you spoken to anyone today? Remember, even a brief chat can brighten your day. I'm here if you'd like to share something or just talk."
      });
    });
    
    // Medication reminders
    cron.schedule('* * * * *', () => { // Check every minute for scheduled medications
      const now = moment().format('HH:mm');
      
      this.db.all(
        `SELECT * FROM medication_reminders 
         WHERE scheduled_time LIKE '${now}%' AND taken = FALSE`,
        (err, reminders) => {
          if (err) {
            console.error('Error fetching medication reminders:', err);
            return;
          }
          
          for (const reminder of reminders) {
            // Emit medication reminder to the user
            this.io.to(reminder.user_id).emit('medication-reminder', {
              medication_name: reminder.medication_name,
              dosage: reminder.dosage,
              message: `It's time for your ${reminder.medication_name} (${reminder.dosage}). Remember to take it with water if appropriate.`
            });
          }
        }
      );
    });
  }

  start(port = process.env.PORT || 3004) {
    this.server.listen(port, () => {
      console.log(`Elderly Isolation Combatant Agent server running on port ${port}`);
    });
  }
}

module.exports = ElderlyIsolationCombatant;
# Elderly Isolation Combatant Agent - API Documentation

## Overview
The Elderly Isolation Combatant Agent provides a warm, empathetic, patient digital companion designed specifically to help combat loneliness and social isolation in older adults (seniors, elderly individuals).

## WebSocket Events

### Client -> Server

#### `init-session`
Initialize a new session with the agent.

Payload:
```json
{
  "userId": "optional user ID (socket ID used if not provided)"
}
```

#### `message`
Send a message to the agent.

Payload:
```json
{
  "message": "Your message text",
  "userId": "optional user ID"
}
```

#### `log-mood`
Log your current mood and loneliness levels.

Payload:
```json
{
  "moodLevel": "1-10 scale",
  "lonelinessLevel": "1-10 scale",
  "notes": "Optional notes about your mood",
  "userId": "optional user ID"
}
```

#### `setup-medication-reminder`
Set up a medication reminder.

Payload:
```json
{
  "medicationName": "Name of the medication",
  "dosage": "Dosage information",
  "scheduledTime": "HH:MM format",
  "userId": "optional user ID"
}
```

#### `medication-taken`
Mark a medication as taken.

Payload:
```json
{
  "medicationName": "Name of the medication",
  "userId": "optional user ID"
}
```

#### `setup-daily-activity`
Set up a daily activity reminder.

Payload:
```json
{
  "activityType": "meal|walk|hydration|exercise|social",
  "scheduledTime": "HH:MM format",
  "userId": "optional user ID"
}
```

#### `activity-completed`
Mark a daily activity as completed.

Payload:
```json
{
  "activityType": "meal|walk|hydration|exercise|social",
  "userId": "optional user ID"
}
```

#### `connect-family`
Initiate a family connection.

Payload:
```json
{
  "contactName": "Name of family member to contact",
  "contactMethod": "call|video_call|visit",
  "userId": "optional user ID"
}
```

#### `setup-virtual-event`
Set up a virtual event.

Payload:
```json
{
  "eventName": "Name of the event",
  "eventType": "game|remembrance|chat_group|educational",
  "scheduledDatetime": "YYYY-MM-DD HH:MM:SS",
  "userId": "optional user ID"
}
```

### Server -> Client

#### `message`
Response from the agent.

Payload:
```json
{
  "type": "greeting|response",
  "content": "The agent's response",
  "timestamp": "ISO timestamp"
}
```

#### `mood-log-confirmed`
Confirmation that mood was logged.

Payload:
```json
{
  "moodLevel": "1-10 scale",
  "lonelinessLevel": "1-10 scale",
  "timestamp": "ISO timestamp",
  "guidance": "Connection-focused guidance"
}
```

#### `medication-reminder-setup`
Confirmation that medication reminder was set up.

Payload:
```json
{
  "medicationName": "Name of the medication",
  "dosage": "Dosage information",
  "scheduledTime": "HH:MM format",
  "message": "Confirmation message"
}
```

#### `medication-marked-taken`
Confirmation that medication was marked as taken.

Payload:
```json
{
  "medicationName": "Name of the medication",
  "takenTime": "ISO timestamp",
  "message": "Confirmation message"
}
```

#### `daily-activity-setup`
Confirmation that daily activity was set up.

Payload:
```json
{
  "activityType": "meal|walk|hydration|exercise|social",
  "scheduledTime": "HH:MM format",
  "message": "Confirmation message"
}
```

#### `activity-marked-completed`
Confirmation that daily activity was marked as completed.

Payload:
```json
{
  "activityType": "meal|walk|hydration|exercise|social",
  "completionTime": "ISO timestamp",
  "message": "Confirmation message"
}
```

#### `family-connection-guidance`
Guidance for family connection.

Payload:
```json
{
  "contactName": "Name of family member",
  "contactMethod": "call|video_call|visit",
  "contactDetails": {
    "name": "Contact name",
    "phone": "Phone number",
    "email": "Email address",
    "relationship": "Relationship",
    "availability": "morning|afternoon|evening|anytime"
  },
  "guidance": "Connection guidance"
}
```

#### `virtual-event-setup`
Confirmation that virtual event was set up.

Payload:
```json
{
  "eventName": "Name of the event",
  "eventType": "game|remembrance|chat_group|educational",
  "scheduledDatetime": "YYYY-MM-DD HH:MM:SS",
  "message": "Confirmation message"
}
```

#### `daily-check-in`
Daily reminder to connect with someone.

Payload:
```json
{
  "message": "Check-in reminder message"
}
```

#### `medication-reminder`
Reminder to take medication.

Payload:
```json
{
  "medication_name": "Name of the medication",
  "dosage": "Dosage information",
  "message": "Reminder message"
}
```

## REST API Endpoints

### GET `/health`
Health check endpoint.

Response:
```json
{
  "status": "OK",
  "timestamp": "ISO timestamp"
}
```

### GET `/api/preferences/:userId`
Get user preferences.

Response:
```json
{
  "response_speed": "slow|medium|fast",
  "medication_reminder_enabled": true,
  "daily_checkin_enabled": true,
  "family_connect_enabled": true,
  "contact_names": ["array", "of", "contact", "names"]
}
```

### POST `/api/preferences/:userId`
Update user preferences.

Payload:
```json
{
  "response_speed": "slow|medium|fast",
  "medication_reminder_enabled": true,
  "daily_checkin_enabled": true,
  "family_connect_enabled": true,
  "contact_names": ["array", "of", "contact", "names"]
}
```

Response:
```json
{
  "message": "Preferences updated successfully"
}
```

### GET `/api/mood-history/:userId`
Get mood history for the user.

Query Parameters:
- `days`: Number of days to retrieve (default: 30)

Response:
```json
[
  {
    "id": 1,
    "user_id": "user123",
    "timestamp": "ISO timestamp",
    "mood_level": 5,
    "loneliness_level": 3,
    "notes": "Feeling okay today"
  }
]
```

### GET `/api/family-contacts/:userId`
Get family contacts for the user.

Response:
```json
[
  {
    "id": 1,
    "user_id": "user123",
    "name": "John Smith",
    "phone": "555-1234",
    "email": "john@example.com",
    "relationship": "Son",
    "availability": "evening"
  }
]
```

### GET `/api/crisis-resources`
Get crisis resources information.

Response:
```json
{
  "crisis_hotline": "988",
  "suicide_prevention": "988",
  "national_hopeline": "1-800-SUICIDE (1-800-784-2433)",
  "samhsa": "1-800-662-4357",
  "crisis_text_line": "Text HOME to 741741"
}
```

## Features

### Loneliness Detection
- Mood and loneliness level tracking
- Conversation-based loneliness detection
- Tone and pattern analysis

### Social Connection Facilitation
- Family connection coordination
- Virtual event scheduling
- In-person meetup suggestions
- Community group connections

### Daily Wellness Support
- Medication reminders
- Meal and hydration prompts
- Movement and exercise suggestions
- Routine establishment

### Safety Monitoring
- Distress detection
- Crisis intervention protocols
- Professional referral guidance
- 24/7 availability
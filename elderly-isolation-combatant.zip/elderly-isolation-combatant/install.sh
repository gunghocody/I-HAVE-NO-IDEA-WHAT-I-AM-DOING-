#!/bin/bash
echo "Installing Elderly Isolation Combatant Agent..."

# Install dependencies
npm install

# Create database
node -e "const sqlite3 = require('sqlite3').verbose(); const db = new sqlite3.Database('./isolation-combat.db'); setTimeout(() => db.close(), 1000);"

echo "Setup complete!"
echo "Copy .env.example to .env and configure your settings:"
echo "  cp .env.example .env"
echo "  nano .env  # or edit with your preferred editor"
echo ""
echo "Run 'node server.js' to start the service."
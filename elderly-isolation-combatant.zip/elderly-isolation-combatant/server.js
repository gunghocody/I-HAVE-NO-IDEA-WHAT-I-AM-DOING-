const ElderlyIsolationCombatant = require('./index');

// Initialize and start the Elderly Isolation Combatant Agent
const agent = new ElderlyIsolationCombatant();
agent.start();
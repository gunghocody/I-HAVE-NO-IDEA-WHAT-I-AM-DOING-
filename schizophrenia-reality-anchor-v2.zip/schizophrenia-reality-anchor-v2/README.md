# Schizophrenia Reality Anchor Agent v2

## Overview
The Schizophrenia Reality Anchor Agent is a compassionate, non-judgmental digital companion designed to help users who experience hallucinations or perceptual distortions anchor themselves in shared, verifiable reality. This agent provides gentle, empathetic support using evidence-based reality checking techniques.

## Mission
- Help users distinguish between internal perceptions and objective external reality
- Offer collaborative, evidence-based reality checking
- Use multi-sensor cross-verification logic
- Provide grounding techniques and safety-focused support

## Key Features
- Empathetic and non-judgmental responses
- Structured reality-testing steps
- Multi-sensory verification guidance
- Grounding techniques (5-4-3-2-1 method)
- Crisis de-escalation capabilities
- Professional referral guidance

## Installation
```bash
npm install
cp .env.example .env
# Configure your .env file with necessary credentials
node index.js
```
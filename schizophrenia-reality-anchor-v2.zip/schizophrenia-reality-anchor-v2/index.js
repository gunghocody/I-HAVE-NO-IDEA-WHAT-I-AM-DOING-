const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const sqlite3 = require('sqlite3').verbose();
const cron = require('node-cron');
const cors = require('cors');
const helmet = require('helmet');
const fs = require('fs').promises;
const path = require('path');
require('dotenv').config();

class SchizophreniaRealityAnchorAgent {
  constructor() {
    this.app = express();
    this.server = http.createServer(this.app);
    this.io = new socketIo.Server(this.server, {
      cors: {
        origin: "*",
        methods: ["GET", "POST"]
      }
    });
    
    // Initialize database
    this.db = new sqlite3.Database(process.env.DB_PATH || './sra.db');
    this.initDatabase();
    
    // Set up middleware
    this.setupMiddleware();
    
    // Set up routes
    this.setupRoutes();
    
    // Set up socket handlers
    this.setupSocketHandlers();
    
    // Initialize session tracking
    this.activeSessions = new Map();
    
    // Schedule maintenance tasks
    this.scheduleTasks();
  }

  setupMiddleware() {
    this.app.use(helmet());
    this.app.use(cors());
    this.app.use(express.json());
    this.app.use(express.static('public'));
  }

  initDatabase() {
    const db = this.db;
    
    db.serialize(() => {
      // Sessions table
      db.run(`CREATE TABLE IF NOT EXISTS sessions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT UNIQUE,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        last_interaction DATETIME DEFAULT CURRENT_TIMESTAMP,
        status TEXT DEFAULT 'active'
      )`);

      // Interactions table
      db.run(`CREATE TABLE IF NOT EXISTS interactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        session_id TEXT,
        user_message TEXT,
        agent_response TEXT,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
        emotion_tag TEXT
      )`);

      // Reality checks table
      db.run(`CREATE TABLE IF NOT EXISTS reality_checks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        session_id TEXT,
        check_type TEXT,
        description TEXT,
        result TEXT,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
      )`);

      // Grounding exercises table
      db.run(`CREATE TABLE IF NOT EXISTS grounding_exercises (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        session_id TEXT,
        exercise_type TEXT,
        completed BOOLEAN DEFAULT FALSE,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
      )`);
    });
  }

  setupRoutes() {
    // Health check endpoint
    this.app.get('/health', (req, res) => {
      res.json({ status: 'OK', timestamp: new Date().toISOString() });
    });

    // Get session status
    this.app.get('/api/session/:userId', (req, res) => {
      const { userId } = req.params;
      const session = this.activeSessions.get(userId);
      
      if (session) {
        res.json({
          active: true,
          sessionId: session.sessionId,
          createdAt: session.createdAt,
          lastInteraction: session.lastInteraction
        });
      } else {
        res.status(404).json({ active: false });
      }
    });

    // Crisis resources endpoint
    this.app.get('/api/crisis-resources', (req, res) => {
      res.json({
        crisis_hotline: process.env.CRISIS_HOTLINE_NUMBER || "988",
        suicide_prevention: "988",
        national_hopeline: "1-800-SUICIDE (1-800-784-2433)",
        samhsa: "1-800-662-4357",
        crisis_text_line: "Text HOME to 741741"
      });
    });
  }

  setupSocketHandlers() {
    this.io.on('connection', (socket) => {
      console.log('New user connected:', socket.id);

      // Handle new messages
      socket.on('message', async (data) => {
        await this.handleMessage(socket, data);
      });

      // Handle reality check requests
      socket.on('reality-check', async (data) => {
        await this.handleRealityCheck(socket, data);
      });

      // Handle grounding exercise requests
      socket.on('grounding-exercise', async (data) => {
        await this.handleGroundingExercise(socket, data);
      });

      // Handle session initialization
      socket.on('init-session', async (data) => {
        await this.initializeSession(socket, data);
      });

      // Handle disconnection
      socket.on('disconnect', () => {
        console.log('User disconnected:', socket.id);
        this.cleanupSession(socket);
      });
    });
  }

  async initializeSession(socket, data) {
    const userId = data.userId || socket.id;
    
    // Create or update session in database
    this.db.run(
      `INSERT OR REPLACE INTO sessions (user_id, last_interaction, status) 
       VALUES (?, CURRENT_TIMESTAMP, 'active')`,
      [userId],
      (err) => {
        if (err) {
          console.error('Error initializing session:', err);
          return;
        }
        
        // Track in memory
        this.activeSessions.set(userId, {
          sessionId: socket.id,
          userId: userId,
          createdAt: new Date(),
          lastInteraction: new Date()
        });
        
        // Send initial greeting
        const initialGreeting = this.getInitialGreeting();
        socket.emit('message', {
          type: 'greeting',
          content: initialGreeting,
          timestamp: new Date().toISOString()
        });
      }
    );
  }

  getInitialGreeting() {
    return `Hi, I'm your Schizophrenia Reality Anchor Agent. I'm here to help you cross-check perceptions against the shared world using calm, step-by-step reality anchors. You're not alone in this. What's happening right now?`;
  }

  async handleMessage(socket, data) {
    const { message, userId = socket.id } = data;
    
    // Update session last interaction
    this.updateSessionInteraction(userId);
    
    // Process the message with empathy and reality-checking
    const response = await this.generateResponse(message, userId);
    
    // Log the interaction
    this.logInteraction(userId, message, response);
    
    // Emit the response
    socket.emit('message', {
      type: 'response',
      content: response,
      timestamp: new Date().toISOString()
    });
  }

  async generateResponse(userMessage, userId) {
    // Create a tailored response based on the user's message
    // This is where we implement the core logic of the reality anchor agent
    
    // First, determine if the user is in distress
    const isDistressed = this.isDistressed(userMessage);
    
    // Generate an empathetic acknowledgment
    let response = "";
    
    if (isDistressed) {
      response += this.getEmpatheticAcknowlegement(userMessage) + "\\n\\n";
    }
    
    // Add reality-checking guidance based on their message
    response += this.getRealityCheckingGuidance(userMessage);
    
    // Add grounding techniques if needed
    if (isDistressed) {
      response += "\\n\\n" + this.getGroundingTechniques();
    }
    
    // Add professional referral if appropriate
    if (this.shouldReferToProfessional(userMessage)) {
      response += "\\n\\n" + this.getProfessionalReferral();
    }
    
    // End with an open invitation
    response += "\\n\\n" + this.getOpenInvitation();
    
    return response;
  }

  isDistressed(message) {
    // Simple heuristic to detect distress in the message
    const distressIndicators = [
      'scared', 'frightened', 'afraid', 'distressing', 'scary', 
      'upsetting', 'worried', 'panicked', 'overwhelming', 'helpless',
      'alone', 'desperate', 'hopeless', 'terrified', 'anxious'
    ];
    
    const lowerMsg = message.toLowerCase();
    return distressIndicators.some(indicator => lowerMsg.includes(indicator));
  }

  getEmpatheticAcknowlegement(message) {
    // Detect the emotional tone and respond appropriately
    if (this.containsFear(message)) {
      return "That sounds really frightening right now — I'm here with you.";
    } else if (this.containsAnxiety(message)) {
      return "That sounds really upsetting right now — I'm here with you.";
    } else {
      return "That sounds difficult right now — I'm here with you.";
    }
  }

  containsFear(message) {
    const fearWords = ['scared', 'frightened', 'terrified', 'afraid', 'scary'];
    return fearWords.some(word => message.toLowerCase().includes(word));
  }

  containsAnxiety(message) {
    const anxietyWords = ['anxious', 'worried', 'nervous', 'upsetting', 'distressing'];
    return anxietyWords.some(word => message.toLowerCase().includes(word));
  }

  getRealityCheckingGuidance(message) {
    // Determine what type of perception the user is describing
    let guidance = "Let's check the environment together. ";
    
    if (this.containsVisualElements(message)) {
      guidance += "Can you describe what you're seeing in detail? " +
                 "What evidence supports this being real? What evidence might suggest otherwise? " +
                 "Would other people likely see the same thing if they were here?";
    } else if (this.containsAuditoryElements(message)) {
      guidance += "Can you describe what you're hearing in detail? " +
                 "Are others around you hearing the same thing? " +
                 "Can we test it by listening carefully or asking someone nearby?";
    } else if (this.containsTactileElements(message)) {
      guidance += "Can you describe what you're feeling? " +
                 "Can we test it by touching something else to compare sensations?";
    } else {
      guidance += "Can you describe what you're perceiving right now in detail? " +
                 "What evidence supports this being real? What evidence might suggest otherwise? " +
                 "Would other people likely perceive the same thing if they were here?";
    }
    
    guidance += " Can we try a reality check together?";
    
    return guidance;
  }

  containsVisualElements(message) {
    const visualWords = ['see', 'saw', 'vision', 'figure', 'shadow', 'shape', 'form', 'image'];
    return visualWords.some(word => message.toLowerCase().includes(word));
  }

  containsAuditoryElements(message) {
    const auditoryWords = ['hear', 'heard', 'voice', 'voices', 'sound', 'sounds', 'noise', 'noises'];
    return auditoryWords.some(word => message.toLowerCase().includes(word));
  }

  containsTactileElements(message) {
    const tactileWords = ['feel', 'touch', 'touched', 'pressure', 'tingling', 'pain', 'sensation'];
    return tactileWords.some(word => message.toLowerCase().includes(word));
  }

  getGroundingTechniques() {
    return "Let's try a grounding technique to help you connect with the present moment:\\n\\n" +
           "**5-4-3-2-1 Grounding Exercise:**\\n" +
           "- Name 5 things you can see right now\\n" +
           "- Name 4 things you can touch right now\\n" +
           "- Name 3 things you can hear right now\\n" +
           "- Name 2 things you can smell right now\\n" +
           "- Name 1 thing you can taste right now\\n\\n" +
           "Take your time with this. Focus on the tangible, real things around you.";
  }

  shouldReferToProfessional(message) {
    // Determine if the message indicates a need for professional help
    const crisisIndicators = [
      'suicide', 'kill myself', 'hurt myself', 'end it', 'can\\'t go on',
      'self-harm', 'harm myself', 'want to die', 'no reason to live'
    ];
    
    const lowerMsg = message.toLowerCase();
    return crisisIndicators.some(indicator => lowerMsg.includes(indicator));
  }

  getProfessionalReferral() {
    return "**Important:** I'm not a substitute for your care team, but if you're having thoughts of harming yourself, please reach out to a trusted person, a crisis line (call 988), or your clinician. You deserve support.";
  }

  getOpenInvitation() {
    return "What would feel most helpful to check or do right now?\\n\\nI'm staying right here with you — tell me what you're noticing.";
  }

  async handleRealityCheck(socket, data) {
    const { checkType, description, userId = socket.id } = data;
    
    // Log the reality check in the database
    this.db.run(
      'INSERT INTO reality_checks (session_id, check_type, description, result) VALUES (?, ?, ?, ?)',
      [userId, checkType, description, 'pending'],
      (err) => {
        if (err) {
          console.error('Error logging reality check:', err);
        }
      }
    );
    
    // Provide specific guidance based on the type of reality check
    let guidance = "";
    
    switch(checkType) {
      case 'visual':
        guidance = `Let's examine what you're seeing:\\n\\n` +
                  `- Look carefully at the shape, color, and movement\\n` +
                  `- Check if the lighting in the room could be creating shadows or reflections\\n` +
                  `- Try moving to a different angle or distance\\n` +
                  `- If possible, take a photo to examine it more closely\\n` +
                  `- Ask: Is this consistent with what I would expect to see in this environment?`;
        break;
        
      case 'auditory':
        guidance = `Let's examine what you're hearing:\\n\\n` +
                  `- Pay attention to the direction the sound seems to come from\\n` +
                  `- Check if there are environmental sources (appliances, electronics, neighbors)\\n` +
                  `- Try covering your ears to see if the sound persists\\n` +
                  `- Ask: Could this be coming from a real source in the environment?`;
        break;
        
      case 'tactile':
        guidance = `Let's examine what you're feeling:\\n\\n` +
                  `- Focus on the specific location and nature of the sensation\\n` +
                  `- Check if there's anything physically contacting that area\\n` +
                  `- Compare to normal sensations in other parts of your body\\n` +
                  `- Ask: Is there a physical cause for this sensation?`;
        break;
        
      default:
        guidance = `Let's examine this perception:\\n\\n` +
                  `- Describe it in as much detail as possible\\n` +
                  `- Look for consistency with your environment\\n` +
                  `- Check if others around you can perceive the same thing\\n` +
                  `- Ask: Is this consistent with what I would normally experience?`;
    }
    
    socket.emit('reality-check-response', {
      type: 'guidance',
      content: guidance,
      checkType,
      timestamp: new Date().toISOString()
    });
  }

  async handleGroundingExercise(socket, data) {
    const { exerciseType, userId = socket.id } = data;
    
    // Log the grounding exercise in the database
    this.db.run(
      'INSERT INTO grounding_exercises (session_id, exercise_type, completed) VALUES (?, ?, ?)',
      [userId, exerciseType, false],
      (err) => {
        if (err) {
          console.error('Error logging grounding exercise:', err);
        }
      }
    );
    
    let exercise = "";
    
    switch(exerciseType) {
      case '54321':
        exercise = "**5-4-3-2-1 Grounding Exercise:**\\n\\n" +
                  "Focus on:\\n" +
                  "• 5 things you can see: Look around and name five objects you notice\\n" +
                  "• 4 things you can touch: Feel four different textures or objects\\n" +
                  "• 3 things you can hear: Listen carefully and identify three distinct sounds\\n" +
                  "• 2 things you can smell: Notice any scents in your environment\\n" +
                  "• 1 thing you can taste: Notice the taste in your mouth or have a mint/candy ready\\n\\n" +
                  "Take your time with each step, focusing on the concrete, real things around you.";
        break;
        
      case 'breathing':
        exercise = "**Deep Breathing Exercise:**\\n\\n" +
                  "Breathe slowly and deeply:\\n" +
                  "• Inhale for 4 counts\\n" +
                  "• Hold for 4 counts\\n" +
                  "• Exhale for 6 counts\\n" +
                  "• Repeat 5-10 times\\n\\n" +
                  "Focus on the physical sensation of breathing to ground yourself in the present moment.";
        break;
        
      case 'body-scan':
        exercise = "**Body Scan Grounding:**\\n\\n" +
                  "Slowly focus on each part of your body:\\n" +
                  "• Start at your toes and work upward\\n" +
                  "• Notice any tension, warmth, or physical sensations\\n" +
                  "• Consciously relax each muscle group as you move up\\n" +
                  "• Pay attention to the connection between your body and the chair/surface beneath you\\n\\n" +
                  "This helps connect you with your physical presence in the current moment.";
        break;
        
      default:
        exercise = this.getGroundingTechniques();
    }
    
    socket.emit('grounding-exercise-response', {
      type: 'exercise',
      content: exercise,
      exerciseType,
      timestamp: new Date().toISOString()
    });
  }

  updateSessionInteraction(userId) {
    // Update last interaction in database
    this.db.run(
      'UPDATE sessions SET last_interaction = CURRENT_TIMESTAMP WHERE user_id = ?',
      [userId],
      (err) => {
        if (err) {
          console.error('Error updating session interaction:', err);
        }
      }
    );
    
    // Update in-memory session
    const session = this.activeSessions.get(userId);
    if (session) {
      session.lastInteraction = new Date();
    }
  }

  logInteraction(userId, userMessage, agentResponse) {
    // Determine emotion tag based on user message
    const emotionTag = this.detectEmotion(userMessage);
    
    this.db.run(
      'INSERT INTO interactions (session_id, user_message, agent_response, emotion_tag) VALUES (?, ?, ?, ?)',
      [userId, userMessage, agentResponse, emotionTag],
      (err) => {
        if (err) {
          console.error('Error logging interaction:', err);
        }
      }
    );
  }

  detectEmotion(message) {
    // Simple emotion detection based on keywords
    const lowerMsg = message.toLowerCase();
    
    if (this.containsFear(message)) return 'fear';
    if (this.containsAnxiety(message)) return 'anxiety';
    if (lowerMsg.includes('angry') || lowerMsg.includes('mad')) return 'anger';
    if (lowerMsg.includes('sad') || lowerMsg.includes('depressed')) return 'sadness';
    if (lowerMsg.includes('happy') || lowerMsg.includes('good')) return 'positive';
    
    return 'neutral';
  }

  cleanupSession(socket) {
    // Remove from active sessions
    for (let [userId, session] of this.activeSessions.entries()) {
      if (session.sessionId === socket.id) {
        this.activeSessions.delete(userId);
        
        // Update session status in DB
        this.db.run(
          'UPDATE sessions SET status = "inactive" WHERE user_id = ?',
          [userId],
          (err) => {
            if (err) {
              console.error('Error updating session status:', err);
            }
          }
        );
        break;
      }
    }
  }

  scheduleTasks() {
    // Clean up old sessions periodically
    cron.schedule('0 */6 * * *', () => {
      const cutoff = new Date(Date.now() - (parseInt(process.env.MAX_SESSION_DURATION_MINUTES) || 60) * 60 * 1000);
      
      this.db.run(
        'UPDATE sessions SET status = "inactive" WHERE last_interaction < ? AND status = "active"',
        [cutoff.toISOString()],
        (err) => {
          if (err) {
            console.error('Error cleaning up old sessions:', err);
          } else {
            console.log('Cleaned up old sessions');
          }
        }
      );
    });
  }

  start(port = process.env.PORT || 3001) {
    this.server.listen(port, () => {
      console.log(`Schizophrenia Reality Anchor Agent server running on port ${port}`);
      console.log(`Max session duration: ${process.env.MAX_SESSION_DURATION_MINUTES || 60} minutes`);
    });
  }
}

module.exports = SchizophreniaRealityAnchorAgent;
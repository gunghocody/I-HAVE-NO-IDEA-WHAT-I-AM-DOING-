# Schizophrenia Reality Anchor Agent v2 - API Documentation

## Overview
The Schizophrenia Reality Anchor Agent provides a compassionate, non-judgmental digital companion designed to help users who experience hallucinations or perceptual distortions anchor themselves in shared, verifiable reality.

## WebSocket Events

### Client -> Server

#### `init-session`
Initialize a new session with the agent.

Payload:
```json
{
  "userId": "optional user ID (socket ID used if not provided)"
}
```

#### `message`
Send a message to the agent.

Payload:
```json
{
  "message": "Your message text",
  "userId": "optional user ID"
}
```

#### `reality-check`
Request guidance for reality checking.

Payload:
```json
{
  "checkType": "visual|auditory|tactile|other",
  "description": "Description of what you're perceiving",
  "userId": "optional user ID"
}
```

#### `grounding-exercise`
Request a specific grounding exercise.

Payload:
```json
{
  "exerciseType": "54321|breathing|body-scan",
  "userId": "optional user ID"
}
```

### Server -> Client

#### `message`
Response from the agent.

Payload:
```json
{
  "type": "greeting|response",
  "content": "The agent's response",
  "timestamp": "ISO timestamp"
}
```

#### `reality-check-response`
Guidance for reality checking.

Payload:
```json
{
  "type": "guidance",
  "content": "Reality checking guidance",
  "checkType": "visual|auditory|tactile|other",
  "timestamp": "ISO timestamp"
}
```

#### `grounding-exercise-response`
Guidance for grounding exercises.

Payload:
```json
{
  "type": "exercise",
  "content": "Grounding exercise instructions",
  "exerciseType": "54321|breathing|body-scan",
  "timestamp": "ISO timestamp"
}
```

## REST API Endpoints

### GET `/health`
Health check endpoint.

Response:
```json
{
  "status": "OK",
  "timestamp": "ISO timestamp"
}
```

### GET `/api/session/:userId`
Get session status for a user.

Response:
```json
{
  "active": true|false,
  "sessionId": "session ID if active",
  "createdAt": "session creation time",
  "lastInteraction": "last interaction time"
}
```

### GET `/api/crisis-resources`
Get crisis resources information.

Response:
```json
{
  "crisis_hotline": "crisis hotline number",
  "suicide_prevention": "suicide prevention number",
  "national_hopeline": "national hopeline number",
  "samhsa": "SAMHSA number",
  "crisis_text_line": "crisis text line info"
}
```

## Features

### Reality Checking
- Visual perception verification
- Auditory perception verification
- Tactile perception verification
- Multi-sensory cross-validation

### Grounding Techniques
- 5-4-3-2-1 grounding exercise
- Deep breathing exercises
- Body scan meditation
- Environmental awareness

### Emotional Support
- Empathetic acknowledgment
- Non-judgmental responses
- Distress de-escalation
- Professional referral guidance
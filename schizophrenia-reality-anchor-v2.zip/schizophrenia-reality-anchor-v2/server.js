const SchizophreniaRealityAnchorAgent = require('./index');

// Initialize and start the Schizophrenia Reality Anchor Agent
const agent = new SchizophreniaRealityAnchorAgent();
agent.start();
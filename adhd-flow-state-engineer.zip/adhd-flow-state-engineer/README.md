# ADHD Flow State Engineer Agent v1

## Overview
The ADHD Flow State Engineer Agent is a calm, encouraging, non-judgmental digital companion built to help users with ADHD (or similar attention/executive function challenges) engineer sustainable flow states. The agent achieves this by chaining tasks thoughtfully across apps/devices, anticipating and buffering common distractions, and dynamically resequencing workflows to preserve momentum while preventing hyperfocus burnout or crashes.

## Mission
- Guide users to create personalized, momentum-maintaining "flow chains"
- Predict and mitigate distractions
- Auto-resequence or adapt workflows in real-time based on user feedback
- Provide supportive, non-diagnostic assistance for ADHD-related challenges

## Key Features
- Personalized flow chain creation
- Distraction prediction and mitigation
- Dynamic workflow adaptation
- Cross-app/device task chaining
- Hyperfocus burnout prevention
- Evidence-based ADHD strategies

## Installation
```bash
npm install
cp .env.example .env
# Configure your .env file with necessary credentials
node index.js
```
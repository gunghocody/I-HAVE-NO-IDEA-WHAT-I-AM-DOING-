const ADHDFlowStateEngineer = require('./index');

// Initialize and start the ADHD Flow State Engineer Agent
const agent = new ADHDFlowStateEngineer();
agent.start();
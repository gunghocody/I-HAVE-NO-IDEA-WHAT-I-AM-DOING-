const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const sqlite3 = require('sqlite3').verbose();
const cron = require('node-cron');
const cors = require('cors');
const helmet = require('helmet');
const moment = require('moment');
require('dotenv').config();

class ADHDFlowStateEngineer {
  constructor() {
    this.app = express();
    this.server = http.createServer(this.app);
    this.io = new socketIo.Server(this.server, {
      cors: {
        origin: "*",
        methods: ["GET", "POST"]
      }
    });
    
    // Initialize database
    this.db = new sqlite3.Database(process.env.DB_PATH || './adhd-flow.db');
    this.initDatabase();
    
    // Set up middleware
    this.setupMiddleware();
    
    // Set up routes
    this.setupRoutes();
    
    // Set up socket handlers
    this.setupSocketHandlers();
    
    // Initialize session tracking
    this.activeSessions = new Map();
    
    // Initialize user state tracking
    this.userStates = new Map();
    
    // Schedule maintenance tasks
    this.scheduleTasks();
  }

  setupMiddleware() {
    this.app.use(helmet());
    this.app.use(cors());
    this.app.use(express.json());
    this.app.use(express.static('public'));
  }

  initDatabase() {
    const db = this.db;
    
    db.serialize(() => {
      // Sessions table
      db.run(`CREATE TABLE IF NOT EXISTS sessions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT UNIQUE,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        last_interaction DATETIME DEFAULT CURRENT_TIMESTAMP,
        status TEXT DEFAULT 'active'
      )`);

      // Flow chains table
      db.run(`CREATE TABLE IF NOT EXISTS flow_chains (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT,
        name TEXT,
        tasks TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        last_used DATETIME DEFAULT CURRENT_TIMESTAMP
      )`);

      // Work sessions table
      db.run(`CREATE TABLE IF NOT EXISTS work_sessions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT,
        start_time DATETIME,
        end_time DATETIME,
        tasks_completed INTEGER,
        focus_rating INTEGER,
        notes TEXT
      )`);

      // Distraction logs table
      db.run(`CREATE TABLE IF NOT EXISTS distraction_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
        distraction_type TEXT,
        severity INTEGER,
        resolution TEXT
      )`);

      // User preferences table
      db.run(`CREATE TABLE IF NOT EXISTS user_preferences (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT UNIQUE,
        pomodoro_duration INTEGER DEFAULT 25,
        break_duration INTEGER DEFAULT 5,
        max_work_session INTEGER DEFAULT 90,
        distraction_buffer INTEGER DEFAULT 5,
        hyperfocus_threshold INTEGER DEFAULT 90
      )`);
    });
  }

  setupRoutes() {
    // Health check endpoint
    this.app.get('/health', (req, res) => {
      res.json({ status: 'OK', timestamp: new Date().toISOString() });
    });

    // Get user preferences
    this.app.get('/api/preferences/:userId', (req, res) => {
      const { userId } = req.params;
      
      this.db.get(
        'SELECT * FROM user_preferences WHERE user_id = ?',
        [userId],
        (err, row) => {
          if (err) {
            console.error('Error fetching preferences:', err);
            return res.status(500).json({ error: 'Failed to fetch preferences' });
          }
          
          res.json(row || this.getDefaultPreferences());
        }
      );
    });

    // Update user preferences
    this.app.post('/api/preferences/:userId', (req, res) => {
      const { userId } = req.params;
      const prefs = req.body;
      
      this.db.run(
        `INSERT OR REPLACE INTO user_preferences 
         (user_id, pomodoro_duration, break_duration, max_work_session, distraction_buffer, hyperfocus_threshold) 
         VALUES (?, ?, ?, ?, ?, ?)`,
        [
          userId,
          prefs.pomodoro_duration || 25,
          prefs.break_duration || 5,
          prefs.max_work_session || 90,
          prefs.distraction_buffer || 5,
          prefs.hyperfocus_threshold || 90
        ],
        (err) => {
          if (err) {
            console.error('Error updating preferences:', err);
            return res.status(500).json({ error: 'Failed to update preferences' });
          }
          
          res.json({ message: 'Preferences updated successfully' });
        }
      );
    });

    // Get flow chains
    this.app.get('/api/flow-chains/:userId', (req, res) => {
      const { userId } = req.params;
      
      this.db.all(
        'SELECT * FROM flow_chains WHERE user_id = ? ORDER BY last_used DESC',
        [userId],
        (err, rows) => {
          if (err) {
            console.error('Error fetching flow chains:', err);
            return res.status(500).json({ error: 'Failed to fetch flow chains' });
          }
          
          res.json(rows);
        }
      );
    });
  }

  setupSocketHandlers() {
    this.io.on('connection', (socket) => {
      console.log('New ADHD Flow user connected:', socket.id);

      // Handle new messages
      socket.on('message', async (data) => {
        await this.handleMessage(socket, data);
      });

      // Handle flow chain creation
      socket.on('create-flow-chain', async (data) => {
        await this.handleCreateFlowChain(socket, data);
      });

      // Handle start work session
      socket.on('start-work-session', async (data) => {
        await this.handleStartWorkSession(socket, data);
      });

      // Handle end work session
      socket.on('end-work-session', async (data) => {
        await this.handleEndWorkSession(socket, data);
      });

      // Handle distraction report
      socket.on('report-distraction', async (data) => {
        await this.handleDistractionReport(socket, data);
      });

      // Handle session initialization
      socket.on('init-session', async (data) => {
        await this.initializeSession(socket, data);
      });

      // Handle disconnection
      socket.on('disconnect', () => {
        console.log('ADHD Flow user disconnected:', socket.id);
        this.cleanupSession(socket);
      });
    });
  }

  getDefaultPreferences() {
    return {
      pomodoro_duration: parseInt(process.env.DEFAULT_POMODORO_MINUTES) || 25,
      break_duration: parseInt(process.env.DEFAULT_BREAK_MINUTES) || 5,
      max_work_session: parseInt(process.env.MAX_WORK_SESSION_MINUTES) || 90,
      distraction_buffer: parseInt(process.env.NOTIFICATION_BUFFER_MINUTES) || 5,
      hyperfocus_threshold: parseInt(process.env.HYPERFOCUS_WARNING_THRESHOLD_MINUTES) || 90
    };
  }

  async initializeSession(socket, data) {
    const userId = data.userId || socket.id;
    
    // Create or update session in database
    this.db.run(
      `INSERT OR REPLACE INTO sessions (user_id, last_interaction, status) 
       VALUES (?, CURRENT_TIMESTAMP, 'active')`,
      [userId],
      (err) => {
        if (err) {
          console.error('Error initializing session:', err);
          return;
        }
        
        // Track in memory
        this.activeSessions.set(userId, {
          sessionId: socket.id,
          userId: userId,
          createdAt: new Date(),
          lastInteraction: new Date()
        });
        
        // Initialize user state
        this.userStates.set(userId, {
          currentTask: null,
          flowChain: null,
          workStartTime: null,
          isWorking: false,
          focusLevel: 5, // 1-10 scale
          distractionCount: 0,
          lastDistractionTime: null
        });
        
        // Send initial greeting
        const initialGreeting = this.getInitialGreeting();
        socket.emit('message', {
          type: 'greeting',
          content: initialGreeting,
          timestamp: new Date().toISOString()
        });
      }
    );
  }

  getInitialGreeting() {
    return `Hi, I'm your ADHD Flow State Engineer Agent. I'm here to help chain tasks, predict distractions, and re-sequence your workflow so you can ride momentum without the crashes. What's on your plate or how's your focus feeling right now?`;
  }

  async handleMessage(socket, data) {
    const { message, userId = socket.id } = data;
    
    // Update session last interaction
    this.updateSessionInteraction(userId);
    
    // Process the message with empathy and flow-state guidance
    const response = await this.generateResponse(message, userId);
    
    // Log the interaction
    this.logInteraction(userId, message, response);
    
    // Emit the response
    socket.emit('message', {
      type: 'response',
      content: response,
      timestamp: new Date().toISOString()
    });
  }

  async generateResponse(userMessage, userId) {
    // Create a tailored response based on the user's message
    const userState = this.userStates.get(userId) || {};
    
    // First, determine if the user is expressing frustration or difficulty
    const isStruggling = this.isStruggling(userMessage);
    
    // Generate an empathetic acknowledgment
    let response = "";
    
    if (isStruggling) {
      response += this.getEmpatheticAcknowlegement(userMessage) + "\\n\\n";
    }
    
    // Add flow-state guidance based on their message
    response += this.getFlowStateGuidance(userMessage, userId, userState);
    
    // Add practical suggestions if appropriate
    if (this.needsPracticalSuggestions(userMessage)) {
      response += "\\n\\n" + this.getPracticalSuggestions(userMessage, userId, userState);
    }
    
    // Add professional referral if appropriate
    if (this.shouldReferToProfessional(userMessage)) {
      response += "\\n\\n" + this.getProfessionalReferral();
    }
    
    // End with an open invitation
    response += "\\n\\n" + this.getOpenInvitation();
    
    return response;
  }

  isStruggling(message) {
    // Simple heuristic to detect struggle in the message
    const struggleIndicators = [
      'struggling', 'frustrated', 'can\'t focus', 'distracted', 'overwhelmed',
      'stuck', 'can\'t concentrate', 'losing focus', 'scattered', 'spinning'
    ];
    
    const lowerMsg = message.toLowerCase();
    return struggleIndicators.some(indicator => lowerMsg.includes(indicator));
  }

  getEmpatheticAcknowlegement(message) {
    return "That momentum drop sounds frustrating — let's engineer a smoother chain together.";
  }

  getFlowStateGuidance(message, userId, userState) {
    // Determine what type of guidance the user needs
    let guidance = "";
    
    if (this.containsTaskList(message)) {
      guidance += this.suggestFlowChaining(message, userId);
    } else if (this.containsFocusIssue(message)) {
      guidance += this.suggestFocusStrategies(message, userId, userState);
    } else if (this.containsEnergyIssue(message)) {
      guidance += this.suggestEnergyManagement(message, userId, userState);
    } else {
      guidance += this.askAboutCurrentState(userId, userState);
    }
    
    return guidance;
  }

  containsTaskList(message) {
    // Check if the message contains a list of tasks
    const taskWords = ['need to', 'have to', 'should do', 'tasks:', 'todo', 'to do'];
    return taskWords.some(word => message.toLowerCase().includes(word));
  }

  containsFocusIssue(message) {
    const focusWords = ['focus', 'concentrate', 'distracted', 'attention', 'mind wandering', 'spacing out'];
    return focusWords.some(word => message.toLowerCase().includes(word));
  }

  containsEnergyIssue(message) {
    const energyWords = ['energy', 'tired', 'exhausted', 'burned out', 'motivation', 'tired of'];
    return energyWords.some(word => message.toLowerCase().includes(word));
  }

  suggestFlowChaining(message, userId) {
    return "Let's map a flow chain for your tasks! Break them into linked micro-steps, and start with a high-interest 'anchor task' to build momentum. " +
           "Then chain to related tasks. What's your most interesting task to start with?";
  }

  suggestFocusStrategies(message, userId, userState) {
    const prefs = this.getUserPreferences(userId);
    
    return `Let's optimize your focus environment. Consider a modified Pomodoro technique: work for ${prefs.pomodoro_duration} minutes, ` +
           `then take a ${prefs.break_duration} minute break. To avoid distractions, you might want to set up a notification buffer ` +
           `or use body doubling techniques. How does that sound for your current task?`;
  }

  suggestEnergyManagement(message, userId, userState) {
    return "Energy management is key! Consider alternating between high-energy and low-energy tasks, incorporating movement breaks, " +
           "or planning your most challenging work during your peak energy times. What type of tasks do you find most energizing?";
  }

  askAboutCurrentState(userId, userState) {
    return "Let's assess your current state. How would you rate your energy level (1-10)? " +
           "What tasks do you have on your plate right now? " +
           "Are there any specific distractions or obstacles you're facing?";
  }

  needsPracticalSuggestions(message) {
    const practicalIndicators = [
      'how do', 'what should', 'suggest', 'recommend', 'tips', 'help with', 'advice'
    ];
    
    const lowerMsg = message.toLowerCase();
    return practicalIndicators.some(indicator => lowerMsg.includes(indicator));
  }

  getPracticalSuggestions(message, userId, userState) {
    const prefs = this.getUserPreferences(userId);
    
    let suggestions = "**Practical ADHD-Friendly Strategies:**\\n\\n";
    
    suggestions += `• **Modified Pomodoro**: Try ${prefs.pomodoro_duration} min work/${prefs.break_duration} min break cycles\\n`;
    suggestions += "• **Task Chaining**: Link related tasks to build momentum\\n";
    suggestions += "• **Body Doubling**: Imagine a supportive presence working alongside you\\n";
    suggestions += "• **Visual Timers**: Use timers to combat time blindness\\n";
    suggestions += "• **Distraction Buffer**: Plan breaks before you get distracted\\n";
    suggestions += "• **Soft Landings**: Plan gentle transitions from hyperfocus\\n";
    
    return suggestions;
  }

  shouldReferToProfessional(message) {
    // Determine if the message indicates a need for professional help
    const crisisIndicators = [
      'therapy', 'doctor', 'medication', 'professional help', 'clinical'
    ];
    
    const lowerMsg = message.toLowerCase();
    return crisisIndicators.some(indicator => lowerMsg.includes(indicator));
  }

  getProfessionalReferral() {
    return "**Note:** I'm here for workflow engineering, but your care team can help with the bigger picture. I'm not a substitute for ADHD coaching, therapy, or medical treatment.";
  }

  getOpenInvitation() {
    return "What's the first task or energy level right now?\\n\\nReady to build/test this flow chain? Tell me what's shifting.";
  }

  getUserPreferences(userId) {
    // In a real implementation, this would fetch from DB
    // For now, return defaults
    return this.getDefaultPreferences();
  }

  async handleCreateFlowChain(socket, data) {
    const { name, tasks, userId = socket.id } = data;
    
    // Save the flow chain to database
    this.db.run(
      'INSERT INTO flow_chains (user_id, name, tasks, last_used) VALUES (?, ?, ?, CURRENT_TIMESTAMP)',
      [userId, name, JSON.stringify(tasks)],
      (err) => {
        if (err) {
          console.error('Error saving flow chain:', err);
          socket.emit('error', { message: 'Failed to save flow chain' });
          return;
        }
        
        // Update user state
        const userState = this.userStates.get(userId);
        if (userState) {
          userState.flowChain = { name, tasks };
        }
        
        socket.emit('flow-chain-created', {
          name,
          tasks,
          message: 'Flow chain created successfully!'
        });
      }
    );
  }

  async handleStartWorkSession(socket, data) {
    const { userId = socket.id, taskId } = data;
    
    const startTime = new Date();
    
    // Update user state
    const userState = this.userStates.get(userId);
    if (userState) {
      userState.workStartTime = startTime;
      userState.isWorking = true;
      userState.currentTask = taskId;
    }
    
    // Start a work session in DB
    this.db.run(
      'INSERT INTO work_sessions (user_id, start_time) VALUES (?, ?)',
      [userId, startTime.toISOString()],
      (err) => {
        if (err) {
          console.error('Error starting work session:', err);
          socket.emit('error', { message: 'Failed to start work session' });
          return;
        }
        
        socket.emit('work-session-started', {
          startTime,
          message: 'Work session started! Remember to take breaks and watch for distractions.'
        });
      }
    );
    
    // Schedule distraction check
    this.scheduleDistractionCheck(socket, userId);
    
    // Schedule hyperfocus warning
    this.scheduleHyperfocusWarning(socket, userId);
  }

  async handleEndWorkSession(socket, data) {
    const { userId = socket.id, focusRating, notes } = data;
    const endTime = new Date();
    
    // Update user state
    const userState = this.userStates.get(userId);
    if (userState) {
      userState.isWorking = false;
      userState.workStartTime = null;
      userState.currentTask = null;
    }
    
    // Update the work session in DB
    this.db.run(
      `UPDATE work_sessions SET end_time = ?, focus_rating = ?, notes = ? 
       WHERE user_id = ? AND end_time IS NULL
       ORDER BY start_time DESC LIMIT 1`,
      [endTime.toISOString(), focusRating, notes, userId],
      (err) => {
        if (err) {
          console.error('Error ending work session:', err);
          socket.emit('error', { message: 'Failed to end work session' });
          return;
        }
        
        socket.emit('work-session-ended', {
          endTime,
          message: 'Work session ended. Great job maintaining your flow!'
        });
      }
    );
  }

  async handleDistractionReport(socket, data) {
    const { userId = socket.id, distractionType, severity, resolution } = data;
    const timestamp = new Date();
    
    // Update user state
    const userState = this.userStates.get(userId);
    if (userState) {
      userState.distractionCount++;
      userState.lastDistractionTime = timestamp;
    }
    
    // Log the distraction
    this.db.run(
      'INSERT INTO distraction_logs (user_id, distraction_type, severity, resolution) VALUES (?, ?, ?, ?)',
      [userId, distractionType, severity, resolution],
      (err) => {
        if (err) {
          console.error('Error logging distraction:', err);
        }
      }
    );
    
    // Provide distraction recovery guidance
    const guidance = this.getDistractionRecoveryGuidance(distractionType, severity);
    
    socket.emit('distraction-guidance', {
      guidance,
      timestamp: timestamp.toISOString()
    });
  }

  getDistractionRecoveryGuidance(distractionType, severity) {
    let guidance = "It's okay to get distracted - that's completely normal! ";
    
    switch(distractionType) {
      case 'notifications':
        guidance += "Consider enabling 'Do Not Disturb' mode or using apps that temporarily block distracting notifications. ";
        break;
      case 'environmental':
        guidance += "Try creating a more focused environment by reducing visual clutter or using noise-canceling headphones. ";
        break;
      case 'internal':
        guidance += "Notice the thought or feeling without judgment, then gently redirect your attention back to your task. ";
        break;
      case 'novelty':
        guidance += "Acknowledge the interesting thing, but remind yourself you can explore it after your planned break. ";
        break;
      default:
        guidance += "Notice what pulled your attention, then gently redirect back to your task. ";
    }
    
    guidance += "Would you like to adjust your current work session or take a brief break?";
    
    return guidance;
  }

  scheduleDistractionCheck(socket, userId) {
    const interval = parseInt(process.env.DISTRACTION_CHECK_INTERVAL_MINUTES) || 10;
    
    // Schedule a check after the interval
    setTimeout(() => {
      const userState = this.userStates.get(userId);
      if (userState && userState.isWorking) {
        // Send a gentle check-in
        socket.emit('distraction-check', {
          message: "How's your focus holding? Need any adjustments to your work session?",
          timestamp: new Date().toISOString()
        });
      }
    }, interval * 60 * 1000);
  }

  scheduleHyperfocusWarning(socket, userId) {
    const threshold = parseInt(process.env.HYPERFOCUS_WARNING_THRESHOLD_MINUTES) || 90;
    
    // Schedule a warning after the threshold
    setTimeout(() => {
      const userState = this.userStates.get(userId);
      if (userState && userState.isWorking) {
        // Send a hyperfocus warning
        socket.emit('hyperfocus-warning', {
          message: "You've been working for a while! Consider taking a break soon to avoid burnout.",
          timestamp: new Date().toISOString()
        });
      }
    }, threshold * 60 * 1000);
  }

  updateSessionInteraction(userId) {
    // Update last interaction in database
    this.db.run(
      'UPDATE sessions SET last_interaction = CURRENT_TIMESTAMP WHERE user_id = ?',
      [userId],
      (err) => {
        if (err) {
          console.error('Error updating session interaction:', err);
        }
      }
    );
    
    // Update in-memory session
    const session = this.activeSessions.get(userId);
    if (session) {
      session.lastInteraction = new Date();
    }
  }

  logInteraction(userId, userMessage, agentResponse) {
    // This would typically log to a database in a full implementation
    // For now, we'll just track in memory
  }

  cleanupSession(socket) {
    // Remove from active sessions
    for (let [userId, session] of this.activeSessions.entries()) {
      if (session.sessionId === socket.id) {
        this.activeSessions.delete(userId);
        this.userStates.delete(userId);
        
        // Update session status in DB
        this.db.run(
          'UPDATE sessions SET status = "inactive" WHERE user_id = ?',
          [userId],
          (err) => {
            if (err) {
              console.error('Error updating session status:', err);
            }
          }
        );
        break;
      }
    }
  }

  scheduleTasks() {
    // Clean up old sessions periodically
    cron.schedule('0 */6 * * *', () => {
      const cutoff = new Date(Date.now() - 24 * 60 * 60 * 1000); // 24 hours
      
      this.db.run(
        'UPDATE sessions SET status = "inactive" WHERE last_interaction < ? AND status = "active"',
        [cutoff.toISOString()],
        (err) => {
          if (err) {
            console.error('Error cleaning up old sessions:', err);
          } else {
            console.log('Cleaned up old sessions');
          }
        }
      );
    });
  }

  start(port = process.env.PORT || 3002) {
    this.server.listen(port, () => {
      console.log(`ADHD Flow State Engineer Agent server running on port ${port}`);
    });
  }
}

module.exports = ADHDFlowStateEngineer;
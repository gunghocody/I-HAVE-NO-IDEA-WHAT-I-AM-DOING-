# ADHD Flow State Engineer Agent - API Documentation

## Overview
The ADHD Flow State Engineer Agent provides a calm, encouraging, non-judgmental digital companion built to help users with ADHD (or similar attention/executive function challenges) engineer sustainable flow states.

## WebSocket Events

### Client -> Server

#### `init-session`
Initialize a new session with the agent.

Payload:
```json
{
  "userId": "optional user ID (socket ID used if not provided)"
}
```

#### `message`
Send a message to the agent.

Payload:
```json
{
  "message": "Your message text",
  "userId": "optional user ID"
}
```

#### `create-flow-chain`
Create a new flow chain of tasks.

Payload:
```json
{
  "name": "Name for the flow chain",
  "tasks": ["array", "of", "tasks"],
  "userId": "optional user ID"
}
```

#### `start-work-session`
Start a focused work session.

Payload:
```json
{
  "taskId": "ID of the task to work on",
  "userId": "optional user ID"
}
```

#### `end-work-session`
End the current work session.

Payload:
```json
{
  "focusRating": "1-10 rating of focus quality",
  "notes": "Optional notes about the session",
  "userId": "optional user ID"
}
```

#### `report-distraction`
Report a distraction encountered during work.

Payload:
```json
{
  "distractionType": "notifications|environmental|internal|novelty",
  "severity": "1-10 severity rating",
  "resolution": "How you resolved it",
  "userId": "optional user ID"
}
```

### Server -> Client

#### `message`
Response from the agent.

Payload:
```json
{
  "type": "greeting|response",
  "content": "The agent's response",
  "timestamp": "ISO timestamp"
}
```

#### `flow-chain-created`
Confirmation that a flow chain was created.

Payload:
```json
{
  "name": "Name of the flow chain",
  "tasks": ["array", "of", "tasks"],
  "message": "Success message"
}
```

#### `work-session-started`
Confirmation that a work session started.

Payload:
```json
{
  "startTime": "ISO timestamp",
  "message": "Status message"
}
```

#### `work-session-ended`
Confirmation that a work session ended.

Payload:
```json
{
  "endTime": "ISO timestamp",
  "message": "Status message"
}
```

#### `distraction-guidance`
Guidance for recovering from a distraction.

Payload:
```json
{
  "guidance": "Recovery guidance",
  "timestamp": "ISO timestamp"
}
```

#### `distraction-check`
Gentle check-in during work session.

Payload:
```json
{
  "message": "Check-in message",
  "timestamp": "ISO timestamp"
}
```

#### `hyperfocus-warning`
Warning about potential hyperfocus.

Payload:
```json
{
  "message": "Warning message",
  "timestamp": "ISO timestamp"
}
```

## REST API Endpoints

### GET `/health`
Health check endpoint.

Response:
```json
{
  "status": "OK",
  "timestamp": "ISO timestamp"
}
```

### GET `/api/preferences/:userId`
Get user preferences.

Response:
```json
{
  "pomodoro_duration": 25,
  "break_duration": 5,
  "max_work_session": 90,
  "distraction_buffer": 5,
  "hyperfocus_threshold": 90
}
```

### POST `/api/preferences/:userId`
Update user preferences.

Payload:
```json
{
  "pomodoro_duration": 30,
  "break_duration": 7,
  "max_work_session": 60,
  "distraction_buffer": 3,
  "hyperfocus_threshold": 75
}
```

Response:
```json
{
  "message": "Preferences updated successfully"
}
```

### GET `/api/flow-chains/:userId`
Get user's flow chains.

Response:
```json
[
  {
    "id": 1,
    "name": "Example Chain",
    "tasks": "[\"task1\", \"task2\"]",
    "created_at": "ISO timestamp",
    "last_used": "ISO timestamp"
  }
]
```

## Features

### Flow State Engineering
- Personalized flow chain creation
- Task chaining for momentum building
- Modified Pomodoro techniques
- Body doubling simulation

### Distraction Management
- Proactive distraction prediction
- Recovery guidance
- Environmental optimization
- Notification management

### Hyperfocus Prevention
- Timed warnings
- Gentle transitions
- Planned breaks
- Soft landings from deep focus